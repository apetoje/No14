"""max |U_n - U_{n-1}| by 3-adic distance from the diagonal (Remark 3.17: about 0.23 far from the diagonal, n <= 8)."""
import numpy as np
from syracuse_law import laws
N=10; L=laws(N)
def Gall(n):
    M=3**n; p=L[n]; pZ=np.zeros(M); pZ[(np.arange(M)+1)%M]=p
    F=np.fft.fft(pZ); out=np.zeros((M,M))
    for al in range(M):
        if al%3==0: continue
        q=pZ[(pow(al,-1,M)*np.arange(M))%M]
        out[al]=M*np.real(np.fft.ifft(np.conj(np.fft.fft(q))*F))
    return out
prev=Gall(1)
for n in range(2,N+1):
    G=Gall(n); M=3**n; Mp=M//3
    al=np.arange(M)[:,None]; be=np.arange(M)[None,:]
    D=G-prev[al%Mp,be%Mp]
    mask=(np.arange(M)%3!=0)[:,None]&np.ones((1,M),bool)
    # distance to diagonal (al=1,be=0): 3-adic valuation of (al-1, be)
    def v3(x):
        x=np.asarray(x)%M; v=np.zeros(x.shape,int); y=x.copy(); 
        for k in range(n):
            z=(y%3==0)&(v==k)&(y!=0); v[z]+=1; y=np.where(z,y//3,y)
        v[x==0]=n; return v
    dist=np.minimum(v3(al-1+0*be),v3(be+0*al))
    row=[]
    for j in range(0,n):
        sel=mask&(dist==j)
        if sel.any(): row.append('%d:%.4f'%(j,np.abs(D[sel]).max()))
    print('n=%2d  max|G_n-G_{n-1}| by closeness j to diagonal: '%n+' '.join(row),flush=True)
    prev=G
