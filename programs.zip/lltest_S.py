"""Numerical test of the local limit structure on the cycle line (double precision).
Y_n(j) = e^{rho n} psi_n(j):  Y_n(j) = (e^rho ph_n(j) Y_{n-1}(j-1) + Y_n(j-1))/2, ph_n(j) = e(-<2^{j-1}>_{3^n}/3^n),
fronts: B (Y_0 = 1, control 0), W^(m) (Y_m(j) = e^{rho m} 2^{-j}, control 0 afterwards), and the full function
with controls Y_n(0) = e^{rho n} phi_n(1) from crig1200.txt (m <= 1200; later controls are negligible on the line).
Prints, every DN levels: n^{3/2} max_{|s|<=10} |Y| for B and full, and ratios W^(m)/B at the peak point of B.
Usage: python3 lltest.py N DN"""
import sys, math, cmath
import numpy as np
from scipy.signal import lfilter
N = int(sys.argv[1]); DN = int(sys.argv[2])
x = math.log2(3); th = math.log(x / (2 * (x - 1))); rho = -(th * x - math.log(2 * math.exp(th) - 1))
J = int(math.ceil(N * x)) + int(12 * N ** 0.5) + 60
cen = {}
for l in open('crig1200.txt'):
    t = l.split(); cen[int(t[0])] = cmath.exp(complex(float(t[1]), float(t[2])))
MS = [1, 2, 3]
jj = np.arange(1, J + 1); k = jj - 1
B = np.ones(J + 1, complex); F = np.ones(J + 1, complex); W = {}
er = math.exp(rho)
for n in range(1, N + 1):
    nx = n * x; M = 3 ** n
    ph = np.empty(J, complex)
    lo = k < nx
    ph[lo] = np.exp(-2j * np.pi * np.exp2(k[lo] - nx))
    k0 = int(math.ceil(nx)); hi = np.nonzero(~lo)[0]
    if len(hi):
        r = pow(2, k0, M); fr = np.empty(len(hi))
        sh = max(0, M.bit_length() - 60); Md = float(M >> sh)
        for i in range(len(hi)):
            fr[i] = float(r >> sh) / Md; r = (r << 1) % M
        ph[hi] = np.exp(-2j * np.pi * fr)
    def step(Y, y0):
        h = 0.5 * er * ph * Y[:-1]
        out = np.empty(J + 1, complex); out[0] = y0
        out[1:] = lfilter([1.0], [1.0, -0.5], h, zi=[0.5 * y0])[0]
        return out
    B = step(B, 0.0)
    F = step(F, math.exp(rho * n) * cen.get(n, 0.0))
    for m in list(W):
        W[m] = step(W[m], 0.0)
    if n in MS:
        W[n] = math.exp(rho * n) * 0.5 ** np.arange(J + 1) + 0j
    if n % DN == 0:
        s = np.arange(J + 1) - nx; win = np.abs(s) <= 10
        ib = np.argmax(np.abs(B) * win); n32 = n ** 1.5
        rat = " ".join("%d:%.4g%+.4gi" % (m, (W[m][ib] / B[ib]).real, (W[m][ib] / B[ib]).imag) for m in MS if m in W and m < n)
        rf = F[ib] / B[ib]
        i2 = int(np.argmin(np.abs(s + 3.0))); i3 = int(np.argmin(np.abs(s + 15.0)))
        shape = " | shape m=1 at s=-3,-15: " + " ".join("%.4g%+.4gi" % ((W[1][i] / B[i]).real, (W[1][i] / B[i]).imag) for i in (i2, i3))
        shape += " F/B: " + " ".join("%.4g%+.4gi" % ((F[i] / B[i]).real, (F[i] / B[i]).imag) for i in (i2, i3))
        print(n, "s*=%.3f" % s[ib], "B=%.6f" % (n32 * np.abs(B[win]).max()), "F=%.5f" % (n32 * np.abs(F[win]).max()),
              "F/B=%.4g%+.4gi" % (rf.real, rf.imag), rat, shape, flush=True)

s = np.arange(J + 1) - N * x
wt = np.where((s < 0) & (s > -40 * N ** 0.5) & (np.arange(J + 1) >= 1), -s, 0.0); s = np.where(wt > 0, s, 0.0)
def S(Y): return np.sum(wt * np.exp(-th * s) * Y)
SB = S(B)
print("S^B_N = %.6f%+.6fi" % (SB.real, SB.imag))
for m in [1, 2, 3]:
    Sm = S(W[m]); r = Sm / SB
    print("m=%d: S^(m)_N = %.6f%+.6fi   S^(m)/S^B = %.4f%+.4fi   W/B at peak above" % (m, Sm.real, Sm.imag, r.real, r.imag))
