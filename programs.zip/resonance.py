"""Correlations along affine relations in the Collatz case (Section 3.1).
(1) Table 3.1: 3^n P(Y~ - c = 2^e (Y - c) mod 3^n) for n = 15, centres c = -1, 7, -5, 1, e = 1, 3.
(2) Twisted collisions T_n(h) = 3^{n-1} P(W~ = 4^h W mod 3^n), W = 1 + 3 X_{n-1}
    (Proposition 3.7), for h = 1, 2, 3 and n <= 16.
(3) T_17(1) = D_16(1)/2 (Proposition 3.10), with D_n(1) = 3^n P(Z~ = 2 Z), Z = X + 1."""
import numpy as np
from syracuse_law import next_law

def corr(p, n, lam, kap):          # 3^n P(X~ = lam X + kap mod 3^n)
    M = 3**n; y = np.arange(M, dtype=np.int64)
    return M*np.sum(p*p[(lam*y + kap) % M])

p = np.array([1.0]); laws = {}
for n in range(1, 17):
    p = next_law(p, n); laws[n] = p
    if n >= 2:
        M = 3**n; pm = laws[n-1]; x = np.arange(3**(n-1), dtype=np.int64)
        row = []
        for h in (1, 2, 3):
            xp = ((pow(4, h, M)*(1 + 3*x) - 1) % M)//3          # x' with 1+3x' = 4^h (1+3x)
            row.append(3**(n-1)*np.sum(pm*pm[xp % 3**(n-1)]))
        print("n=%2d  T_n(1)=%.5f  T_n(2)=%.6f  T_n(3)=%.6f" % (n, *row), flush=True)
    if n == 15:
        M = 3**n
        for c in (-1, 7, -5, 1):
            vals = [corr(p, n, pow(2, e, M), (c*(1 - pow(2, e, M))) % M) for e in (1, 3)]
            print("centre %3d:  e=1 %.3f   e=3 %.3f" % (c, *vals), flush=True)
D16 = corr(laws[16], 16, 2, 1)        # Z~ = 2Z  <=>  X~ = 2X + 1
print("D_16(1) = %.5f   T_17(1) = D_16(1)/2 = %.5f" % (D16, D16/2))
