"""Archimedean part of the front (Section 11, Lemma 9.6, Section 13):
 B_n(j)=E[e(-2^j Y_{n+1}/3^n); A_n<=j] via B_n(j)=sum_{a<j} 2^-a e(-2^{j-a}/3^n) B_{n-1}(j-a), B_0=1_{j>=0}.
Prints e^{rho n} max_j |B_n(j)|, n^{3/2} times it, and nx - argmax.
Usage: python3 archimedean_part.py 6000   (about one minute)"""
import sys, numpy as np, math
N=int(sys.argv[1]); x=math.log2(3); AMAX=64
th=math.log(x/(2*(x-1))); rho=-(th*x-math.log(2*math.exp(th)-1))
J=int(N*x)+60
B=np.ones(J+1,dtype=complex)  # level 0, j=0..J
for n in range(1,N+1):
    M=3**n; ph=np.empty(J+1,dtype=complex); v=1
    for k in range(J+1):
        ph[k]=np.exp(-2j*math.pi*(v/M)); v=(2*v)%M
    pb=ph*B; new=np.zeros(J+1,dtype=complex)
    for a in range(1,AMAX+1):
        new[a:]+=2.0**-a*pb[:J+1-a]
    new*=math.exp(rho)       # rescale: B holds e^{rho n} B_n
    new[0]=0
    B=new
    if n in (150,1000,2000,3000,4000,5000,6000) or n==N:
        k=int(np.argmax(np.abs(B[1:])))+1; G=abs(B[k])
        print("n=%5d  G=%.5e  n^1.5 G=%.5f  nx-k=%.2f"%(n,G,n**1.5*G,n*x-k),flush=True)
