"""For xi=2^{-b} mod 3^n and lifts Xi=u 2^k (k>=0), the tail at exit time t is phi_m(2^{-b-k}), m=n-t+1, with weight
P(tau=t)=P(Bin(k,1/2)=t-1). It is a central value phi_m(+-1) iff -b-k = 0 mod 3^{m-1}.
Report, for each b, the largest total weight of central tails at levels m>=m_min over all k<=6n."""
import math
def logbinom_pmf(k,i): return math.lgamma(k+1)-math.lgamma(i+1)-math.lgamma(k-i+1)-k*math.log(2)
for n in (30,60,120,240):
    for mmin in (3,5,8):
        best=(0,None,None)
        for b in range(1,21):
            for k in range(0,6*n+1):
                i=-b-k; tot=0.0
                for m in range(mmin,n+1):
                    if i % 3**(m-1)==0:
                        t=n-m+1
                        if 0<=t-1<=k: tot+=math.exp(logbinom_pmf(k,t-1))
                if tot>best[0]: best=(tot,b,k)
        print("n=%3d  levels m>=%d: max total weight of central tails = %.3e  (b=%s, k=%s)"%(n,mmin,best[0],best[1],best[2]))
