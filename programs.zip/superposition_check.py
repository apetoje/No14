"""Check of the superposition principle: phi_n(2^j) = B_n(j) + sum_{m=1}^n phi_m(1) W^(m)_n(j),
W^(m) = front evolution (Lemma 9.6 recursion) of 2^{-j} started at level m."""
import numpy as np, math
from psi_tables import psi
def step(Vprev,n,J):
    M=3**n; ph=np.array([np.exp(-2j*math.pi*(pow(2,k,M)/M)) for k in range(J+1)])
    pv=ph*Vprev; new=np.zeros(J+1,complex)
    for a in range(1,J+1): new[a:]+=2.0**-a*pv[:J+1-a]
    return new
for n in (8,12,15):
    J=int(n*math.log2(3))+10
    B=np.ones(J+1,complex)
    for k in range(1,n+1): B=step(B,k,J); B[0]=0
    tot=B.copy()
    for m in range(1,n+1):
        W=2.0**-np.arange(J+1)+0j
        for k in range(m+1,n+1): W=step(W,k,J); W[0]=0
        tot+=np.conj(psi[m][0])*W      # psi tables use the conjugate convention
    true=np.array([np.conj(psi[n][j%(2*3**(n-1))]) for j in range(J+1)])
    print("n=%d  max|phi_n(2^j) - superposition| over 0<=j<=%d: %.2e"%(n,J,np.max(np.abs(tot[1:]-true[1:]))))
