"""Rigorous lower bound for |P_infty| (Theorem 11.8) from the line function at n0 and the central values.
P_n = P^B + sum_{m<n} phi_m(1) pi_m + phi_n(1) nu_n (proof of Theorem 11.8), hence
P_inf - P_n0 = sum_{m>=n0} phi_m(1) pi_m - phi_n0(1) nu_n0, with
|pi_m| <= e^{sc(m+1)} ((m+1)x + 30.94) q/(1-q)^2,  |nu_m| <= e^{sc m} (m x + 30.94) q/(1-q),  q = 1/(2e^{theta*}),
and |P_n0 - S_n0| <= 30.94 (R_n0 + Rtail) + Serr (Proposition 11.10).  Central values from crig1200.txt
(m <= 1200); for m > 1200 the hypothesis |phi_m(1)| <= C0 e^{-sigma m} is used.
Usage: python3 nondeg.py l420.txt 400 crig1200.txt"""
import sys, math
x=math.log2(3); th=math.log(x/(2*(x-1))); rho=-(th*x-math.log(2*math.exp(th)-1)); sc=rho+th*x
q=1/(2*math.exp(th)); c2=q/(1-q)**2; c1=q/(1-q); C3=30.94
line=[l.split() for l in open(sys.argv[1])]; n0=int(sys.argv[2])
r=line[n0-1]; S=complex(float(r[8]),float(r[9]))
R=float(r[12].split('=')[1]); Rt=float(r[13].split('=')[1]); Se=float(r[14].split('=')[1])
encl=C3*(R+Rt)+Se+1e-6*abs(S)
print("n0=%d  S=%.4f%+.4fi |S|=%.4f  radius %.4f  => |P_n0| >= %.4f"%(n0,S.real,S.imag,abs(S),encl,abs(S)-encl))
cen={}
for l in open(sys.argv[3]):
    t=l.split(); m=int(t[0]); lnp=float(t[1]); rad=float(t[3].split('=')[1])
    cen[m]=math.exp(lnp)+2.0**rad if lnp>-700 else math.exp(lnp+0)+2.0**rad
Mmax=max(cen)
def pib(m): return math.exp(sc*(m+1))*((m+1)*x+C3)*c2
tail=sum(cen[m]*pib(m) for m in range(n0,Mmax+1)) + cen[n0]*math.exp(sc*n0)*(n0*x+C3)*c1
print("rigorous tail m in [%d,%d]: %.6f"%(n0,Mmax,tail))
for sig,C0 in [(0.55,11.4),(0.55,1e3),(0.545,5.9),(0.54,1e2)]:
    h=sum(C0*math.exp(-sig*m+sc*(m+1))*((m+1)*x+C3)*c2 for m in range(Mmax+1,Mmax+200000)); h+=C0*math.exp(-sig*(Mmax+200000)+sc*(Mmax+200001))*((Mmax+200001)*x+C3)*c2/(1-math.exp(-(sig-sc)))**2
    print("hypothesis sigma=%.3f C0=%g for m>%d: tail %.4g  => |P_inf| >= %.4f"%(sig,C0,Mmax,h,abs(S)-encl-tail-h))
