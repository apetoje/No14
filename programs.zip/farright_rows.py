"""Row sums of |kernel| in the far-right region (the region that carries the central values).
Start at level m with a unit mass at t = 0 (frequency 2^0), go down T levels by
A'(t+a) += 2^{-a} e(-<2^{-(t+a)}>_{3^k}/3^k) A(t)  (level k = m, m-1, ...), and print sum_t |A_T(t)|."""
import sys, math, numpy as np
m=int(sys.argv[1]); T=int(sys.argv[2]); Lw=8*T+400; A=np.zeros(Lw,complex); A[0]=1.0
for step in range(T):
    k=m-step; M=3**k; inv2=pow(2,-1,M); r=1; fr=np.empty(Lw)
    for s in range(Lw): fr[s]=r/M if M<2**1000 else float(r>>(M.bit_length()-60))/float(M>>(M.bit_length()-60)); r=(r*inv2)%M
    ph=np.exp(-2j*np.pi*fr)
    new=np.zeros(Lw,complex)
    for a in range(1,60):
        new[a:]+=0.5**a*ph[a:]*A[:Lw-a]
    A=new
    if (step+1) in (8,16,32,64,96,128,160,192) : print("T=%d  sum|A_T| = %.3e   -ln/T = %.4f"%(step+1,np.abs(A).sum(),-math.log(np.abs(A).sum())/(step+1)),flush=True)
