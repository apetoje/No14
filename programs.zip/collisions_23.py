"""Exact energy Q_n, collisions 3^n C_n and the correlation D_n(1) = 3^n P(Z~ = 2Z), Z = X + 1, about the
cycle -1 in the Collatz case for n <= 13 (Table 2; Q_1 = 2/3, Q_2 = 10/21). Usage: python3 collisions_23.py [N]"""
import sys, numpy as np
from syracuse_law import laws

N = int(sys.argv[1]) if len(sys.argv) > 1 else 13
L = laws(N)
D = [3**n*np.sum(L[n]**2) for n in range(N+1)]
for n in range(1, N+1):
    M = 3**n; p = L[n]; pz = np.zeros(M); pz[(np.arange(M)+1) % M] = p
    D1 = M*np.sum(pz*pz[(2*np.arange(M)) % M])
    print("n=%2d  Q_n=%.6f  3^n C_n=%.5f  D_n(1)=%.5f" % (n, D[n]-D[n-1], D[n], D1), flush=True)
