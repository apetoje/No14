"""Minimum over all states of U_n (= G_n) for n <= 10 (Remark 3.17: 0.333, ..., 0.1903)."""
import numpy as np
from syracuse_law import laws
L=laws(10)
for n in range(1,11):
    M=3**n; p=L[n]; pZ=np.zeros(M); pZ[(np.arange(M)+1)%M]=p
    F=np.fft.fft(pZ); mn=np.inf; arg=None
    for al in range(M):
        if al%3==0: continue
        q=pZ[(pow(al,-1,M)*np.arange(M))%M]
        G=M*np.real(np.fft.ifft(np.conj(np.fft.fft(q))*F))
        i=np.argmin(G)
        if G[i]<mn: mn=G[i]; arg=(al,i)
    print(n,'min G_n = %.5f at (al,be)=%s'%(mn,arg))
