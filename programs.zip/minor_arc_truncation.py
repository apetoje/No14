"""Effect of the minor arcs on M_150 (Remark on criticality, Section 5).
Runs the first-order window recursion of Proposition 6.5 for n = 16..150 twice:
(i) unchanged, (ii) with the minor-arc values phi_m(2^k), k <= 0, set to zero at
every level m >= 17 (no injection from the minor arcs above level 16).
Prints M_n in both runs and the relative change of M_150."""
import numpy as np, math
from scipy.signal import lfilter
from psi_tables import *   # exact tables psi[n], n <= 15
x = math.log2(3); n0 = 15; NMAX = 150

def run(truncate):
    R = int(NMAX*x)+60; L = int(n0*x)-400; N0 = 2*3**(n0-1)
    F = psi[n0][np.arange(L, R+1) % N0].astype(complex)
    res = {}
    for n in range(n0+1, NMAX+1):
        M = 3**n; p = pow(2, L, M); sh = 1 << 60; fr = np.empty(R-L)
        for i in range(R-L):
            fr[i] = (p*sh//M)/sh; p = (p*2) % M
        G = 0.5*np.exp(2j*np.pi*fr)*F[:-1]
        F = lfilter([1.0], [1.0, -0.5], G); L += 1
        if truncate and n >= 17:
            F[np.arange(L, R+1) <= 0] = 0.0
        res[n] = np.abs(F).max()
    return res

full = run(False); trunc = run(True)
for n in (16, 30, 50, 100, 150):
    print(n, "M_n full = %.6e" % full[n], " truncated = %.6e" % trunc[n])
print("relative change of M_150: %.1f %%" % (100*abs(trunc[150]-full[150])/full[150]))
