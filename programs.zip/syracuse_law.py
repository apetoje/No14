"""Exact law of the Syracuse random variable X_n mod 3^n (Collatz case).
X_n = 2^{-a}(1 + 3 X'_{n-1}), P(a=k) = 2^{-k}; the geometric series is truncated
at a <= A (default 70), which changes the probabilities by less than 2^{-70}.
Imported by the other programs; laws(N) returns [law_0, ..., law_N]."""
import numpy as np

def next_law(p, n, A=70):
    M = 3**n; q = np.zeros(M)
    base = (1 + 3*np.arange(3**(n-1), dtype=np.int64)) % M
    for a in range(1, A+1):
        q[(pow(2, -a, M)*base) % M] += 2.0**-a * p     # the map is injective for fixed a
    return q/q.sum()

def laws(N, A=70):
    out = [np.array([1.0])]
    for n in range(1, N+1):
        out.append(next_law(out[-1], n, A))
    return out
