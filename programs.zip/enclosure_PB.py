"""Rigorous enclosure of the conserved archimedean pairing P^B (Theorem 11.11(b)).
Input: front2_N<N>.npz from rigorous_front.py (tilted front V^B_N, V^B_{N+1} with absolute error bounds E),
H4_params.json, H4_nodes.npy from build_H4.py (supersolution H_1 of Proposition 11.10, verified by verify_H1.py).
Output: S_N = sum_j (-s_j)_+ V^B_N(j) with error bound, and the tail bound
sum_j H(s^(N)_j)|V^B_N(j)| + sum_j H(s^(N+1)_j)|V^B_{N+1}(j)| of Lemma 11.9(b).
Usage: python3 enclosure_PB.py 20000"""
import numpy as np, json, sys
N=int(sys.argv[1]) if len(sys.argv)>1 else 20000
d=np.load('front2_N%d.npz'%N); u=2.0**-53
p=json.load(open('H4_params.json')); Hn=np.load('H4_nodes.npy')
YL,yc,nint,h,V,Hs=[p[k] for k in ('YL','yc','nint','h','V','Hs')]
nodes=-YL+h*np.arange(nint+1)
def Hup(s):
    s1=s-1e-9; s2=s+1e-9                     # guard for the rounding of s
    a=np.interp(np.clip(s1,-YL,yc),nodes,Hn); b=np.interp(np.clip(s2,-YL,yc),nodes,Hn)
    m=np.maximum(a,b); m=np.where(s2>yc,np.maximum(m,Hs),m); m=np.where(s1<-YL,V,m)   # F<=V on (-inf,-YL)
    return m*(1+4*u)
s0,V0,E0,s1,V1,E1=[d[k] for k in ('s0','V0','E0','s1','V1','E1')]
w=np.maximum(-s0,0)
S=np.sum(w*V0); K=len(s0)
errS=np.sum(w*E0)*(1+1e-12)+(K+8)*u*np.sum(w*np.abs(V0))*2+np.sum(np.abs(V0))*1e-9
tail=(np.sum(Hup(s0)*(np.abs(V0)+E0))+np.sum(Hup(s1)*(np.abs(V1)+E1)))*(1+(K+8)*u)
print('S_N =',S,' error <=',errS)
print('|S_N| =',abs(S),' tail bound =',tail)
print('rigorous: |P^B| >=',abs(S)-errS-tail)
