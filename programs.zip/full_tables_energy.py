"""Energy Q_n = sum over units of |phi_n(xi)|^2 in the Collatz case (Table 3.2, Conjecture 3.11)
and the energy on the major arcs E_n = sum_{0<=j<=nx} |phi_n(+-2^j)|^2 (Section 12).
The tables phi_n(2^k), k mod 2*3^(n-1), are computed by the first-order recursion of
Proposition 6.5 (2 is a primitive root mod 3^n). Usage: python3 energy_Q.py [nmax<=17]"""
import sys, math, numpy as np
from scipy.signal import lfilter
nmax = int(sys.argv[1]) if len(sys.argv) > 1 else 17
x = math.log2(3)

def pow2_mod(N, M):
    out = np.empty(N, dtype=np.int64); out[0] = 1; L = 1
    while L < N:
        m = min(L, N-L); out[L:L+m] = (out[:m]*pow(2, L, M)) % M; L += m
    return out

prev = None; Eprev = None
for n in range(1, nmax+1):
    M = 3**n; N = 2*3**(n-1)
    g = np.exp(2j*np.pi*pow2_mod(N, M)/M)*(np.tile(prev, 3) if n > 1 else 1)*0.5
    y = lfilter([1.0], [1.0, -0.5], np.roll(g, 1)); pl = y[-1]/(1-0.5**N)
    K = min(N, 1200); y[:K] += (0.5**np.arange(1, K+1))*pl
    a = np.abs(y)**2
    j = np.arange(0, int(n*x)+1); E = a[j % N].sum() + a[(j+N//2) % N].sum()
    line = "n=%2d  Q_n=%.6f  M_n=%.6e  E_n=%.6e" % (n, a.sum(), math.sqrt(a.max()), E)
    if Eprev: line += "  E_n/E_{n-1}=%.3f" % (E/Eprev)
    print(line, flush=True)
    prev, Eprev = y, E
