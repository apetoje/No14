"""Explicit constants in Theorem 11.11(c).
For n >= 2, k = n-1, U = U_k (sum of k independent steps x-a, a ~ q), the tail of the pairing outside |s| <= t is
  T(n,t) <= sum_{y in 1-x+Z_{>=0}} f(y) E[(|y|+|U|+C3) 1{|U|>t-|y|}],  f(y) = e^{rho-theta* y},
bounded with P(|U|>r) <= 2exp(-r^2/(2kv)) for r <= lam0 v k, E[|U| 1{|U|>r}] <= P(|U|>r)(r+kv/r) + (4/lam0)e^{-lam0^2 v k/2},
and E|U| <= sqrt(k x(x-1)); terms with |y| <= t/2 use r = t/2, terms with |y| > t/2 use the trivial bound.
Here v = sup_{|lam|<=1/2} Lambda_U''(lam) = r0/(1-r0)^2, r0 = beta* e^{1/2}, C3 = 30.94 (Proposition 11.10),
|P^B| >= 0.06771 (Theorem 11.11(b)), t_n = 7.97 sqrt((n-1) log n).
The program checks T(n,t_n) <= |P^B|/2 for every n with 226 <= n <= NMAX, and for n > NMAX a monotone majorant
(each of its terms decreasing in n) at n = NMAX. Usage: python3 explicit_constant.py 20000"""
import math, sys
import numpy as np
NMAX=int(sys.argv[1]) if len(sys.argv)>1 else 20000
x=math.log2(3); be=(x-1)/x; th=math.log(x/(2*(x-1))); rho=-(th*x-math.log(2*math.exp(th)-1))
lam0=0.5; r0=be*math.exp(lam0); v=r0/(1-r0)**2*(1+1e-9)
C3=30.94; PB=0.06771; A=7.97; var=x*(x-1)
I=np.arange(1,4000); Y=I-x; F=np.exp(rho-th*Y); AY=np.abs(Y)
def tn(n): return A*math.sqrt((n-1)*math.log(n))
def T(n):
    k=n-1; t=tn(n); r=t/2
    assert r<=lam0*v*k
    P=2*math.exp(-r*r/(2*k*v)); EU=P*(r+k*v/r)+(4/lam0)*math.exp(-lam0*lam0*v*k/2)
    near=AY<=r
    return float(np.sum(F[near]*((AY[near]+C3)*P+EU))+np.sum(F[~near]*(AY[~near]+math.sqrt(k*var)+C3)))
def majorant(n):     # all y counted as near, plus the far terms y > t/2; every term is decreasing in n for n >= NMAX
    k=n-1; t=tn(n); r=t/2
    P=2*math.exp(-r*r/(2*k*v)); EU=P*(r+k*v/r)+(4/lam0)*math.exp(-lam0*lam0*v*k/2)
    far=Y>r
    return float(np.sum(F*((AY+C3)*P+EU))+np.sum(F[far]*(Y[far]+math.sqrt(k*var)+C3)))
print("v = %.6f, 4 sqrt(v) = %.5f <= 7.97, theta* 7.97 = %.4f"%(v,4*math.sqrt(v),th*A))
bad=[n for n in range(226,NMAX+1) if T(n)>PB/2]
print("n in [226,%d] with T(n,t_n) > |P^B|/2:"%NMAX, bad)
print("T(225) = %.5f, T(226) = %.5f, |P^B|/2 = %.5f"%(T(225),T(226),PB/2))
print("majorant at NMAX = %.3e"%majorant(NMAX))
