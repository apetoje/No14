"""Statistics of the half-line values f_m(t) = phi_m(2^{-t}), t < 8m+400 (Lemma 12.1(a)), double precision:
median and quantiles of 3^m |f_m(t)|^2 (Remark 12.3). Usage: python3 halfline_stats.py N"""
import numpy as np, sys, math
N=int(sys.argv[1]); L=8*N+400; A=100
f=np.ones(L,complex); w=0.5**np.arange(1,A+1)
for m in range(1,N+1):
    M=3**m; inv2=pow(2,-1,M); x=1; fr=np.empty(L)
    for s in range(L): fr[s]=x/M; x=(x*inv2)%M
    g=np.concatenate([np.exp(-2j*np.pi*fr)*f, np.zeros(A+1)])
    f=np.array([np.dot(w,g[t+1:t+A+1]) for t in range(L)])
    if m%5==0:
        a=np.abs(f[:8*m])**2*3.0**m
        print(m, "mean 3^m|f_m(t)|^2 over t<8m: %.3f   3^m|f_m(0)|^2: %.3g   median %.3f"%(a.mean(), a[0], np.median(a)))
