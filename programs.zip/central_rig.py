"""Rigorous enclosures of the central values phi_m(1), 1 <= m <= N.

Lemma 2.1 at j = -t <= 0:  f_m(t) = phi_m(2^{-t}) = sum_{a>=1} 2^{-a} e(-<2^{-t-a}>_{3^m}/3^m) f_{m-1}(t+a),
f_0 = 1, evaluated as f_m(t) = (g(t+1) + f_m(t+1))/2, g(s) = e(-<2^{-s}>/3^m) f_{m-1}(s), 0 <= t < L.
The unknown value f_m(L-1) (true modulus <= 1) is replaced by 0.

Error bound for every entry: |true - computed| <= E u + 2^T, u = 2^-P, where (fixp.FP error model)
  E channel (units u):   E_g(s) = E(s)(1+1e-6) + sqrt2,  E_new(t) = (E_g(t+1) + E_new(t+1))/2 + sqrt2;
  T channel (log2, abs): T_g(s) = log2( 2^{T(s)+1e-9} + 77 u |f_hat(s)| ),  T_new(t) = log2((2^{T_g(t+1)} + 2^{T_new(t+1)})/2),
  with T_new(L-1) = 0 (the replaced value), E = 0 and T = -inf for f_0.
(The relative phase error is < 77 u, so |e_hat f_hat - e f| <= |e_hat||f_hat - f| + 77u |f|, |e_hat| <= 1+77u.)
Output per m: ln|phi_hat|, arg, log2 of the error radius.   Usage: python3 central_rig.py N P"""
import sys, math
from fixp import FP, PHASE_ERR, SQ2, log2add
N = int(sys.argv[1]); P = int(sys.argv[2]); F = FP(P)
L = 8 * N + 400
f = [(F.S, 0)] * L; E = [0.0] * L; T = [-math.inf] * L
for m in range(1, N + 1):
    M = 3 ** m; inv2 = pow(2, -1, M); r = 1
    g = [None] * L
    for s in range(L):
        g[s] = F.cmul(F.phase_frac(r, M), f[s]); r = (r * inv2) % M
    new = [None] * L; En = [0.0] * L; Tn = [-math.inf] * L
    new[L - 1] = (0, 0); Tn[L - 1] = 0.0
    for t in range(L - 2, -1, -1):
        s = t + 1
        new[t] = ((g[s][0] + new[t + 1][0]) >> 1, (g[s][1] + new[t + 1][1]) >> 1)
        En[t] = 0.5 * (E[s] * (1 + 1e-6) + SQ2 + En[t + 1]) + SQ2
        ab = F.absf(f[s])
        tg = log2add(T[s] + 1e-9, math.log2(PHASE_ERR * ab) - P if ab > 0 else -math.inf)
        Tn[t] = log2add(tg, Tn[t + 1]) - 1.0
    f, E, T = new, En, Tn
    rad = log2add(math.log2(E[0]) - P, T[0])
    z = f[0]; sh = max(0, max(abs(z[0]), abs(z[1])).bit_length() - 60)
    print(m, "%.10f" % F.lnabs(z), "%.6f" % math.atan2(z[1] >> sh, z[0] >> sh),
          "log2rad=%.2f" % rad, "log2|phi|=%.2f" % (F.lnabs(z) / math.log(2)), flush=True)
