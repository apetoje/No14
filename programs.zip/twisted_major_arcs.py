"""Twisted major arcs (end of Section 8).
(1) Largest |phi_n| at units of the form +-(3^{n-1} - 2^k) (case s = 1 of Theorem 6.4) for n = 12, 15,
    compared with M_n.
(2) Ratio of the largest value outside the set M_n(R) of units +-2^k + eta 3^{n-s}, 0<=k<=nx+1,
    0<=s<=R, to M_n, for R = 0, 1, 2 and n = 6, 10, 15."""
import numpy as np, math
from psi_tables import *
x = math.log2(3)
for n in (12, 15):
    M = 3**n; N = 2*3**(n-1); p2 = pow2_mod(N, M); inv = np.empty(M, dtype=np.int64); inv[p2] = np.arange(N)
    a = np.abs(psi[n]); vals = []
    for k in range(0, int(n*x)+2):
        xi = (3**(n-1) - 2**k) % M
        if xi % 3: vals.append((a[inv[xi]], k))
    vals.sort(reverse=True)
    print("n=%d  M_n=%.5f  top values at +-(3^{n-1}-2^k): " % (n, a.max()) + ", ".join("k=%d: %.5f" % (k, v) for v, k in vals[:3]))
for R in (0, 1, 2):
    out = []
    for n in (6, 10, 15):
        M = 3**n; N = 2*3**(n-1); p2 = pow2_mod(N, M); a = np.abs(psi[n]); maj = set()
        for r in range(0, R+1):
            for eta in range(3**r):
                for k in range(0, int(n*x)+2):
                    for sgn in (1, -1):
                        v = (sgn*2**k + eta*3**(n-r)) % M
                        if v % 3: maj.add(v)
        mask = np.isin(p2, np.array(sorted(maj), dtype=np.int64))
        out.append("n=%d: %.3f" % (n, a[~mask].max()/a.max()))
    print("R=%d  max outside M_n(R) / M_n: " % R + "  ".join(out), flush=True)
