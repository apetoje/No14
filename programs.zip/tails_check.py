"""Tails of the archimedean front (Conjecture 12.10(c), Remark 12.13), double precision:
sum over |s| > A sqrt(n) of (1+|s|)|V^B_n|, and the mass to the right of the line. Usage: python3 tails_check.py N1 N2 ..."""
import sys, math
import numpy as np
from scipy.signal import lfilter
x=math.log2(3); th=math.log(x/(2*(x-1))); rho=-(th*x-math.log(2*math.exp(th)-1)); sig2=x*(x-1)
Ns=[int(v) for v in sys.argv[1:]]; N=max(Ns)
J=int(math.ceil(N*x))+int(12*N**0.5)+60; jj=np.arange(1,J+1); k=jj-1
B=np.ones(J+1,complex); er=math.exp(rho)
for n in range(1,N+1):
    nx=n*x; M=3**n; ph=np.empty(J,complex); lo=k<nx
    ph[lo]=np.exp(-2j*np.pi*np.exp2(k[lo]-nx))
    hi=np.nonzero(~lo)[0]
    if len(hi):
        r=pow(2,int(math.ceil(nx)),M); sh=max(0,M.bit_length()-60); Md=float(M>>sh); fr=np.empty(len(hi))
        for i in range(len(hi)): fr[i]=float(r>>sh)/Md; r=(r<<1)%M
        ph[hi]=np.exp(-2j*np.pi*fr)
    h=0.5*er*ph*B[:-1]; out=np.empty(J+1,complex); out[0]=0
    out[1:]=lfilter([1.0],[1.0,-0.5],h,zi=[0.0])[0]; B=out
    if n in Ns:
        s=np.arange(J+1)-nx; V=np.exp(-th*s)*B   # tilted
        print("n=%d"%n)
        ok=(s>-40*n**0.5); V=np.where(ok,np.exp(-th*np.where(ok,s,0))*B,0)
        for A in [2.0,3.0,4.0]:
            print("   A=%.0f: sum_{|s|>A sqrt n}(1+|s|)|V| = %.3e   sum_{s>0.5 sqrt n}(1+|s|)|V| = %.3e"%(A,np.sum(((np.abs(s)>A*n**0.5))*(1+np.abs(s))*np.abs(V)),np.sum((s>0.5*n**0.5)*(1+np.abs(s))*np.abs(V))))
        print("   total sum (1+|s|)|V| = %.4f ; S = %.5f%+.5fi"%(np.sum((1+np.abs(s))*np.abs(V)), np.sum(np.where(s<0,-s,0)*V).real, np.sum(np.where(s<0,-s,0)*V).imag))
