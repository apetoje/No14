"""Amplitude of one-sided parts above the line: start at level m0 with a point mass at s in [s1, s1+1],
evolve by the front recursion (same phases as B), and kill everything that enters s < sI (set to 0 after
each level). Prints the total tilted mass sum_j |V_t(j)| as a function of the duration t."""
import math, sys
import numpy as np
from scipy.signal import lfilter
x=math.log2(3); th=math.log(x/(2*(x-1))); rho=-(th*x-math.log(2*math.exp(th)-1))
m0=int(sys.argv[1]); T=int(sys.argv[2]); s1=float(sys.argv[3]); sI=float(sys.argv[4])
N=m0+T; J=int(math.ceil(N*x))+400; jj=np.arange(1,J+1); k=jj-1; er=math.exp(rho)
Y=np.zeros(J+1,complex); s0=np.arange(J+1)-m0*x; i0=int(np.argmin(np.abs(s0-s1-0.5))); Y[i0]=math.exp(th*s0[i0])  # V=1 at the start
for n in range(m0+1,N+1):
    nx=n*x; M=3**n; ph=np.empty(J,complex); lo=k<nx
    ph[lo]=np.exp(-2j*np.pi*np.exp2(k[lo]-nx)); hi=np.nonzero(~lo)[0]
    r=pow(2,int(math.ceil(nx)),M); sh=max(0,M.bit_length()-60); Md=float(M>>sh); fr=np.empty(len(hi))
    for i in range(len(hi)): fr[i]=float(r>>sh)/Md; r=(r<<1)%M
    ph[hi]=np.exp(-2j*np.pi*fr)
    h=0.5*er*ph*Y[:-1]; out=np.empty(J+1,complex); out[0]=0; out[1:]=lfilter([1.0],[1.0,-0.5],h,zi=[0.0])[0]
    s=np.arange(J+1)-nx; out[s<sI]=0; Y=out
    t=n-m0
    if t in (1,2,4,8,16,32,64,128,256) or t==T:
        Vabs=np.abs(Y)*np.exp(-th*np.clip(s,-700/th,700/th)); Vpos=np.abs(Y)
        print("t=%4d  sum|V| (tilted) = %.3e   positive-kernel comparison t^-1.5 = %.3e"%(t,Vabs.sum(),t**-1.5),flush=True)
