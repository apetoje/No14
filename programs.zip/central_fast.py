"""Central values phi_n(1) via Lemma 2.1 restricted to the half-line j <= 0:
f_m(t) = phi_m(2^{-t}) satisfies f_m(t) = sum_{a>=1} 2^{-a} e(-<2^{-t-a}>_{3^m}/3^m) f_{m-1}(t+a), f_0 = 1.
Double-precision exploration version; entries beyond the array are set to 0 (error <= P(A_n > L))."""
import numpy as np, sys
N=int(sys.argv[1]); L=4*N+200; A=100
f=np.ones(L,complex); w=0.5**np.arange(1,A+1)
for m in range(1,N+1):
    M=3**m; inv2=pow(2,-1,M); x=1; fr=np.empty(L)
    for s in range(L): fr[s]=x/M; x=(x*inv2)%M
    g=np.concatenate([np.exp(-2j*np.pi*fr)*f, np.zeros(A+1)])
    new=np.array([np.dot(w,g[t+1:t+A+1]) for t in range(L)])
    f=new
    print(m, abs(f[0]), f[0].real, f[0].imag, flush=True)
