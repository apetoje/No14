"""Independent check: exact law of Syrac(Z/3^n) (Tao, Lemma 1.12) and M_n for n <= 6, compared with the recursion tables (Section 8, Appendix A)."""
import numpy as np
# exact law of Syrac(Z/3^n) via Syrac_n = 2^{-a}(1+3 S_{n-1}), a~Geom(2), using period 2*3^(n-1) in a
def law(n):
    P=np.array([1.0])  # Z/1
    for m in range(1,n+1):
        M=3**m; Q=np.zeros(M); per=2*3**(m-1)
        inv2=pow(2,-1,M)
        w=np.array([0.5**a for a in range(1,per+1)])/(1-0.5**per)
        xs=np.arange(3**(m-1))
        base=(1+3*xs)%M
        for a in range(1,per+1):
            y=(base*pow(inv2,a,M))%M
            np.add.at(Q,y,w[a-1]*P)
        P=Q
    return P
for n in range(1,7):
    P=law(n); M=3**n
    F=np.fft.fft(P)  # F[xi]=sum P(x) e(-x xi/M)
    units=[x for x in range(M) if x%3]
    print(n, max(abs(F[u]) for u in units))
