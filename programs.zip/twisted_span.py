"""Conditional line values psi^{(z)}_n(j)=E[e(-2^j X_n/3^n); X_n = z mod 3^s] = B^{(z)}(j)+sum_t W^{(z)}_t(j) c_{n-t+1} + R.
DP over (A_i, X_i mod 3^s). Checks the identity against exact laws and measures dist(B_stack, span W_stack)."""
import numpy as np, math, sys
from scipy.signal import lfilter
def build(n,s,J):
    S=3**s; ph={}
    for r in range(1,n+1):
        M=3**r; v=1; a=np.empty(J+1,dtype=complex)
        for k in range(J+1): a[k]=np.exp(-2j*math.pi*v/M); v=(2*v)%M
        ph[r]=a
    inv2=pow(2,-1,S) if S>1 else 0
    pinv=np.array([pow(inv2,A,S) if S>1 else 0 for A in range(J+1)])   # 2^{-A} mod 3^s
    W=np.zeros((S,J,n),dtype=complex); B=np.zeros((S,J),dtype=complex); R=np.zeros(J)
    for j in range(1,J+1):
        Ar=np.arange(j+1)
        D=np.zeros((j+1,S),dtype=complex); D[0,0]=1.0   # D[A,z]
        for i in range(1,n+1):
            # exit at t=i (uses D_{i-1}): weight 2^{-(j-A)}
            w=(D*(2.0**-(j-Ar))[:,None]).sum(0)
            if i<=s: R[j-1]+=np.abs(w).sum()   # exits at t<=s go to R (bounded by prob)
            else: W[:,j-1,i-1]=w
            # step: A -> A+a ; z -> z+3^{i-1} 2^{-A_i} (only i<=s); phase e(-2^{j-A_i}3^{i-1}/3^n)
            G=lfilter([0,0.5],[1,-0.5],D,axis=0)
            if i<=s:
                newD=np.zeros_like(G)
                add=(3**(i-1)*pinv[:j+1])%S
                for z in range(S):
                    newD[np.arange(j+1),(z+add)%S]+=G[:,z]
                G=newD
            D=G*ph[n-i+1][j-Ar][:,None]
        B[:,j-1]=D.sum(0)
    return B,W,R
if __name__=="__main__":
    mode=sys.argv[1]
    if mode=="check":
        from syracuse_law import laws
        from psi_tables import psi
        n,s=int(sys.argv[2]),int(sys.argv[3]); J=int(n*math.log2(3))+8
        B,W,R=build(n,s,J); L=laws(n); p=L[n]; M=3**n; S=3**s
        c=np.array([np.conj(psi[n-t+1][0]) for t in range(1,n+1)])
        y=np.arange(M); err=0
        for z in range(S):
            for j in range(1,J+1):
                true=np.sum(p[y%S==z]*np.exp(-2j*math.pi*((pow(2,j,M)*y[y%S==z])%M)/M))
                err=max(err,abs(B[z,j-1]+W[z,j-1]@c-true)-R[j-1])
        print("n=%d s=%d: max |identity residual| - R = %.2e, max R=%.2e"%(n,s,err,R.max()))
    else:
        for n in [int(a) for a in sys.argv[3:]]:
            s=int(sys.argv[2]); J=int(n*math.log2(3))+20
            B,W,R=build(n,s,J)
            jsel=np.arange(J)[np.arange(1,J+1)>=2*s+10]   # where R is tiny
            Bs=B[:,jsel].reshape(-1); Ws=W[:,jsel,:].reshape(-1,n)
            c,*_=np.linalg.lstsq(Ws,-Bs,rcond=None)
            d=np.linalg.norm(Bs+Ws@c)
            print("n=%d s=%d rows=%d: ||B||=%.3e dist=%.3e ratio=%.3e max|c|=%.2e  maxR=%.1e"%(n,s,len(Bs),np.linalg.norm(Bs),d,d/np.linalg.norm(Bs),np.abs(c).max(),R[jsel].max()),flush=True)
