"""Tail of the real Syracuse variable Y = sum_i 3^{i-1} 2^{-A_i} (Remark 7.2): Monte Carlo estimate of y P(Y>y)
for y = 10, 100, 1000 with 2*10^6 samples, the series truncated after 300 terms."""
import numpy as np
rng = np.random.default_rng(11); Ns = 2_000_000; Y = np.zeros(Ns); W = np.ones(Ns)/3.0
for m in range(300):
    W *= 3.0*np.exp2(-rng.geometric(0.5, size=Ns).astype(float)); Y += W
print("y P(Y>y):", [round(float(np.mean(Y > y))*y, 2) for y in (10, 100, 1000)])
