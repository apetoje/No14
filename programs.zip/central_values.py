"""Central values phi_m(1) in the Collatz case (caption of Table 8 and Section 12):
3^{m/2}|phi_m(1)| for m = 21, 51, 101, 151, 300 and max_{m>=150} e^{sigma_c m}|phi_m(1)|,
sigma_c = ln log_{3/2} 2. Same window recursion as conjecture_H_check.py.
Usage: python3 central_values.py 300 -3000"""
import numpy as np, sys, math
from scipy.signal import lfilter
from psi_tables import *
n0 = 15; MMAX = int(sys.argv[1]); L = int(sys.argv[2]); R = 8; N0 = 2*3**(n0-1)
sc = math.log(math.log(2)/math.log(1.5))
F = psi[n0][np.arange(L, R+1) % N0].astype(complex); worst = 0.0
for m in range(n0+1, MMAX+1):
    M = 3**m; W = R-L; p = pow(2, L, M); fr = np.empty(W); sh = 1 << 60
    for i in range(W):
        fr[i] = (p*sh//M)/sh; p = p*2 % M
    F = lfilter([1.0], [1.0, -0.5], 0.5*np.exp(2j*np.pi*fr)*F[:-1]); L += 1
    c = abs(F[-L])                                     # index of j = 0 is -L
    if m in (21, 51, 101, 151, 300):
        print("m=%3d  3^{m/2}|phi_m(1)| = %.3f" % (m, 3**(m/2)*c), flush=True)
    if m >= 150:
        v = math.exp(sc*m)*c
        if v > worst: worst, mworst = v, m
print("max_{150<=m<=%d} e^{sigma_c m}|phi_m(1)| = %.2e at m=%d" % (MMAX, worst, mworst))
