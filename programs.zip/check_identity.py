"""Check of the decomposition phi_n(2^j) = B_n(j) + sum_t w_t(j) phi_{n-t+1}(1) on the cycle line
(Proposition 9.5, exit form) against the exact tables of psi_tables.py for n = 6, 10, 13 (differences ~1e-16).
Usage: python3 check_identity.py"""
import numpy as np, math, sys
sys.path.insert(0,'.')
from span_distance import build
from psi_tables import psi
for n in (6,10,13):
    J=int(n*math.log2(3))+10; B,W=build(n,J)
    c=np.array([np.conj(psi[n-t+1][0]) for t in range(1,n+1)])
    P=2*3**(n-1); true=np.array([np.conj(psi[n][j%P]) for j in range(1,J+1)])
    print(n, np.max(np.abs(B+W@c-true)), np.max(np.abs(true)))
