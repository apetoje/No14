"""Harmonic function V = lim T~^N (-s)_+ of the tilted front operator (Theorem 11.4) computed on the continuum
(step 1/64, domain [-160,30], N = 6000); prints the normalized wave |W|/max (Table 5, second row), the position of
the maximum s* = -6.78 and the variation of arg W on [-60,-5] (Remark 10.8, about 0.34 pi)."""
import numpy as np, math
x=math.log2(3); be=(x-1)/x
h=1/64; S0=-160.0; S1=30.0
s=np.arange(S0,S1+h/2,h); N=len(s)
A=np.arange(1,120); q=(1-be)*be**(A-1)
V0=np.maximum(-s,0.0)
def T(V):
    out=np.zeros(N,complex)
    for a,qa in zip(A,q):
        t=s+x-a
        idx=(t-S0)/h
        i0=np.floor(idx).astype(int); fr=idx-i0
        inside=(i0>=0)&(i0<N-1)
        val=np.where(t<S0, -t+0j, 0j)          # far left: free harmonic extension (-t)
        ii=np.clip(i0,0,N-2)
        val=np.where(inside, V[ii]*(1-fr)+V[ii+1]*fr, val)
        out+=qa*np.exp(-2j*np.pi*np.exp2(s-a))*val
    return out
V=V0.astype(complex)
for it in range(1,6001):
    V=T(V)
    if it in (100,500,1000,2000,4000,6000):
        R=V-V0
        W=np.exp(0.303618*s)*V
        imax=np.argmax(np.abs(W)*(s>-60))
        print(it,'sup|R| on [-100,30]=%.4f'%np.abs(R[(s>-100)]).max(),'R(-50)=%s'%np.round(R[np.argmin(abs(s+50))],4),
              '|V(10)|=%.2e'%abs(V[np.argmin(abs(s-10))]),'argmax|W|=%.3f'%s[imax],flush=True)
np.save('V.npy',V)
W=np.exp(0.303618*s)*V; m=np.abs(W).max()
for t in [-13.25,-9.25,-7.25,-5.25,-3.25,-1.25,0.75]:
    print(t, '%.3f'%(abs(W[np.argmin(abs(s-t))])/np.abs(W[(s>-60)]).max()))
m=(s>=-60)&(s<=-5); ar=np.unwrap(np.angle(W[m]))
print('variation of arg W on [-60,-5] / pi = %.3f'%((ar.max()-ar.min())/math.pi))
