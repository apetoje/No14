"""Values 3^n c_n, c_n = min over b not divisible by 3 of P(X_n = b mod 3^n), for n = 2, 4, ..., 14
(paragraph after Proposition 3.22). Uses the exact law of syracuse_law.py.
Usage: python3 cn_values.py 14"""
import sys, numpy as np
from syracuse_law import laws
N=int(sys.argv[1]) if len(sys.argv)>1 else 14
L=laws(N)
for n in range(2,N+1,2):
    M=3**n; b=np.arange(M); p=L[n][b%3!=0]
    print(n, round(M*p.min(),4))
