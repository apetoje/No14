"""Uniformity of the decay of the restricted evolution above the line over the starting point t0
(Conjecture 12.18, numerics after Theorem 12.19). Usage: python3 ur_uniform.py m T"""
import sys, math, numpy as np
def rows(m,T,t0):
    Lw=8*T+400+t0; A=np.zeros(Lw,complex); A[t0]=1.0
    for step in range(T):
        k=m-step; M=3**k; inv2=pow(2,-1,M); r=1; fr=np.empty(Lw); sh=max(0,M.bit_length()-60); Md=float(M>>sh)
        for s in range(Lw): fr[s]=float(r>>sh)/Md; r=(r*inv2)%M
        ph=np.exp(-2j*np.pi*fr); new=np.zeros(Lw,complex)
        for a in range(1,60): new[a:]+=0.5**a*ph[a:]*A[:Lw-a]
        A=new
    return np.abs(A).sum()
T=int(sys.argv[2]); m=int(sys.argv[1])
vals=[(t0,rows(m,T,t0)) for t0 in list(range(0,16))]
for t0,v in vals: print("m=%d T=%d t0=%4d  sum|A_T| = %.3e  rate %.4f"%(m,T,t0,v,-math.log(v)/T))
