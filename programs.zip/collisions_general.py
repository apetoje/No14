"""Collision energy for general (p,q,C) with uniform digits (Section 3).
Computes the exact law of X_n mod q^n from X_n = p^{-a}(c + q X'_{n-1}),
P(a=k) = (p-1) p^{-k}, c uniform on C, and prints
  q^n C_n, Q_n = q^n C_n - q^{n-1} C_{n-1}, R_n = q^n C_n - q*pi*q^{n-1} C_{n-1}
(Theorem 3.3) and R_n / gamma^n with gamma = q ((p-1)/p)^2 max nu(c)^2
(Proposition 3.6), and M_1 for the remark after Corollary 3.4.
Usage: python3 collisions_general.py p q c1,c2,... nmax"""
import sys, numpy as np
p, q = int(sys.argv[1]), int(sys.argv[2])
C = [int(c) for c in sys.argv[3].split(',')]; nmax = int(sys.argv[4])
nu = 1.0/len(C); A = 60
pi = (p-1)/(p+1)*len(C)*nu**2; gamma = q*((p-1)/p)**2*nu**2
law = np.array([1.0]); prev = 1.0
print("(p,q,C)=", (p, q, C), " q*pi = %.4f  gamma = %.4f" % (q*pi, gamma))
for n in range(1, nmax+1):
    M = q**n; new = np.zeros(M); y = np.arange(q**(n-1))
    for a in range(1, A+1):
        inv = pow(p, -a, M); w = (p-1)*float(p)**(-a)
        for c in C:
            np.add.at(new, (inv*(c+q*y)) % M, w*nu*law)
    law = new/new.sum(); Cn = float(np.sum(law**2))
    D, Dp = M*Cn, M//q*prev
    Qn, Rn = D-Dp, D-q*pi*Dp
    line = "n=%d  q^nC_n=%.5f  Q_n=%.5f  R_n=%.5f  R_n/gamma^n=%.4f" % (n, D, Qn, Rn, Rn/gamma**n)
    if n == 1:
        F = np.fft.fft(law); units = [u for u in range(1, M) if np.gcd(u, q) == 1]
        line += "  M_1=%.4f  bound of Cor.3.4=%.4f" % (max(abs(F[u]) for u in units),
                 ((q*pi-1)/((q-1)*pi))**0.5*pi**0.5 if q*pi > 1 else float('nan'))
    print(line, flush=True); prev = Cn
