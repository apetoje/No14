"""Rigorous verification of the supersolution inequality of Proposition 11.10 for H_2 (H5_params.json, H5_nodes.npy):
   H(y) >= G(y) + G_1(y) + sum_c Q2(c) gamma_c(y-2x+c) H(y-2x+c)  for all real y,  G_1(z) = sum_a q(a) G(z-x+a).
Same method as verify_H1.py. Usage: python3 verify_H2.py"""
import numpy as np, math, json, time
from decimal import Decimal as D
import rig
t0=time.time()
p=json.load(open('H5_params.json')); Hn=np.load('H5_nodes.npy')
YL,yc,nint,h,lam,B,V,Hs=[p[k] for k in ('YL','yc','nint','h','lam','B','V','Hs')]
CK=8; CMAX=120; u=2.0**-53
X=rig.X; BE=(X-1)/X; xlo,xhi=rig.lo(X),rig.up(X); EPSX=1e-12
Q2=np.array([rig.up((c-1)*(1-BE)**2*BE**(c-2)) for c in range(2,CMAX+1)]); C=np.arange(2,CMAX+1)
tailQ=rig.up((1-BE)**2*BE**(CMAX-1)*(D(CMAX)/(1-BE)+BE/(1-BE)**2))   # sum_{c>CMAX}(c-1)(1-b)^2 b^{c-2}
nodes=-YL+h*np.arange(nint+1)
assert np.all(Hn>0) and Hn[nodes>=yc-(2*xhi-2)-1e-9].max()<=Hs and max(Hn.max(),Hs)<=V
Hmax=V
DL=D(repr(lam)); DB=D(repr(B)); DV=D(repr(V))
def Fup(t): return np.array([rig.up(DV-DB*(DL*D(repr(float(tt)))).exp()) for tt in np.atleast_1d(t)])
def Hext(lo,hi,mode):
    if mode=='max': lo=lo-EPSX; hi=hi+EPSX
    a=np.interp(np.clip(lo,-YL,yc),nodes,Hn); b=np.interp(np.clip(hi,-YL,yc),nodes,Hn)
    a=np.where(lo>yc,Hs,a); b=np.where(hi>yc,Hs,b)
    k=np.ceil((np.clip(lo,-YL,yc)+YL)/h); tn=-YL+h*k; inside=(tn>lo)&(tn<hi)&(tn<=yc)
    c3=np.interp(np.clip(tn,-YL,yc),nodes,Hn); jr=(lo<=yc)&(hi>yc)
    if mode=='max':
        m=np.maximum(a,b); m=np.where(inside,np.maximum(m,c3),m); m=np.where(jr,np.maximum(m,Hs),m)
        L=np.nonzero(lo<-YL)[0]
        if len(L): m[L]=np.maximum(m[L],Fup(lo[L]))
        return m*(1+4*u)
    m=np.minimum(a,b); m=np.where(inside,np.minimum(m,c3),m); m=np.where(jr,np.minimum(m,Hs),m)
    assert not np.any(lo<-YL); return m*(1-4*u)
def T_up(z):  # T(-z) for z<=0 : E(a-x-u)_+ with u=-z, closed form, upper bound
    uu=-D(repr(float(z))); k0=int((X+uu).to_integral_value(rounding='ROUND_FLOOR'))+1
    return rig.up(BE**(k0-1)*((k0-X-uu)+BE/(1-BE)))
def f1(z): z=D(repr(float(z))); return 2*rig.PI*rig.exp2(z-X)*(-z)
F1MAX=2*rig.PI*D(-1).exp()*rig.exp2(-X)/rig.LN2
def Gup0(lo,hi):
    out=np.empty(len(lo)); z0=-1/math.log(2)
    for i,(a,b) in enumerate(zip(lo,hi)):
        if b<=0:
            cand=[f1(a),f1(b)]
            if a<z0<b: cand.append(F1MAX)   # exact maximum 2*pi*e^{-1}*2^{-x}/ln2 at z0=-1/ln2 (f1 unimodal)
            out[i]=rig.up(max(cand))+T_up(b)
        elif a>=0: out[i]=max(0.0,rig.up((1-BE)*(X-1-D(repr(float(a))))))
        else: out[i]=max(Gup0(np.array([a]),np.array([0.0]))[0],Gup0(np.array([0.0]),np.array([b]))[0])
    # unimodality: f1'(z)=2pi 2^{z-x}(-1 - z ln2) vanishes only at z0
    return out
A0=45
qup=[rig.up((1-BE)*BE**(a-1)) for a in range(1,A0+1)]; qtail=rig.up(BE**A0)
GMAX=rig.up(F1MAX)+rig.up((1-BE)*(X-1))          # sup G <= max f1 + T(0), T(0)=(1-b)(x-1)
def Gup(lo,hi):   # upper bound of G + G1, G1(z)=sum_a q(a) G(z-x+a) >= |T~* g*|(z)
    out=Gup0(lo,hi)
    for a in range(1,A0+1):
        out=out+qup[a-1]*Gup0(lo+a-xhi-EPSX,hi+a-xlo+EPSX)
    return (out+qtail*GMAX)*(1+64*u)+1e-15
# --- Gamma cell tables
WC=1/4096; S0=-8.0
gam={}
import os
for c in range(3,CK+1):
    if os.path.exists('gam_%d_%d.npy'%(c,int(1/WC))): gam[c]=np.load('gam_%d_%d.npy'%(c,int(1/WC))); continue
    ncell=int(round((c-1-S0)/WC)); tab=np.ones(ncell)
    for i in range(ncell):
        clo=S0+i*WC; chi=clo+WC; mid=D(repr(clo+WC/2))
        re=D(0); im=D(0)
        for a in range(1,c):
            t=rig.exp2(mid-a); fr=t-t.to_integral_value(rounding='ROUND_FLOOR')
            re+=rig.cos2pi(fr); im+=rig.sin2pi(fr)
        mod=rig.up((re*re+im*im).sqrt()/(c-1))
        Lc=2*math.pi*math.log(2)*sum(2.0**(chi-a) for a in range(1,c))/(c-1)*(1+1e-9)
        tab[i]=min(1.0,mod+Lc*WC/2)
    gam[c]=tab; np.save('gam_%d_%d.npy'%(c,int(1/WC)),tab)
print("Gamma tables %.0fs"%(time.time()-t0),flush=True)
def gamma_up(c,slo,shi):
    slo=slo-EPSX; shi=shi+EPSX; out=np.ones(len(slo))
    ok=(slo>=S0)&(shi<c-1)
    i0=np.floor((slo-S0)/WC).astype(int); i1=np.floor((shi-S0)/WC).astype(int)
    n=len(gam[c]); i0c=np.clip(i0,0,n-1); i1c=np.clip(i1,0,n-1)
    span=int((i1-i0).max()); m=gam[c][i0c].copy()
    for d in range(1,span+1): m=np.maximum(m,gam[c][np.clip(np.minimum(i0+d,i1),0,n-1)])
    return np.where(ok,m,1.0)
# --- (a) interior
delta=h/4; pts=np.unique(np.concatenate([np.arange(-YL,yc,delta),[0.0,xlo-1,xhi-1,yc]])); pts=pts[(pts>=-YL)&(pts<=yc)]
lo=pts[:-1]; hi=pts[1:]
straddle=(lo<xhi-1)&(hi>xlo-1)
G_=Gup(lo,hi); print("G %.0fs"%(time.time()-t0),flush=True)
S=np.zeros(len(lo))
for k,c in enumerate(C):
    slo,shi=lo+c-2*xhi,hi+c-2*xlo
    g=gamma_up(c,slo,shi) if 3<=c<=CK else 1.0
    S+=Q2[k]*g*Hext(slo,shi,'max')
EPS=2*(CMAX+8)*u*(S+Hmax)+1e-14
lowA=Hext(lo,hi,'min')-G_-S-tailQ*Hmax-EPS
print("(a) interior [-40,5]: rigorous min lower bound = %.4e at y=%.5f (%d intervals)"%(lowA.min(),lo[lowA.argmin()],len(lo)),flush=True)
# --- (b) far left [-80,-40] in difference form
Mlow=rig.lo(sum(((c-1)*(1-BE)**2*BE**(c-2)*(DL*(c-2*X)).exp() for c in range(2,CMAX+1)),D(0)))
lo2=np.arange(-YL-40,-YL,delta); hi2=lo2+delta
gain=np.array([rig.lo(DB*(D(repr(Mlow))-1)*(DL*D(repr(float(a)))).exp()) for a in lo2])
ehi=np.array([rig.up((DL*D(repr(float(b)))).exp()) for b in hi2])
ec=np.array([rig.up((DL*(c-2*X)).exp()) for c in range(2,CMAX+1)])
G2=Gup(lo2,hi2); R=np.zeros(len(lo2))
# rigorous cell table of max(H-F) on interior cells [nodes[i],nodes[i+1]]: H linear (max at ends), F decreasing (min at right end)
Fmin_cell=np.array([rig.lo(DV-DB*(DL*D(repr(float(t)))).exp()) for t in nodes[1:]])
Fmin_cell=np.array([rig.lo(DV-DB*D(repr(rig.up((DL*D(repr(float(t)))).exp())))) for t in nodes[1:]])
Dcell=np.maximum(np.maximum(Hn[:-1],Hn[1:])*(1+4*u)-Fmin_cell,0)
for k,c in enumerate(C):
    slo=lo2+c-2*xhi-EPSX; shi=hi2+c-2*xlo+EPSX
    rel=shi>=-YL
    if not rel.any(): continue
    i0=np.floor((np.clip(slo,-YL,yc)-(-YL))/h).astype(int); i1=np.floor((np.clip(shi,-YL,yc)-(-YL))/h).astype(int)
    i0=np.clip(i0,0,nint-1); i1=np.clip(i1,0,nint-1)
    dmax=np.maximum(Dcell[i0],Dcell[i1]); assert np.all(i1-i0<=1)
    right=shi>yc
    dR=np.maximum(Hs-V+B*ehi*ec[k]*(1+8*u),0)
    d=np.where(right,np.maximum(dmax,dR),dmax)
    R+=np.where(rel,Q2[k]*d,0)
R+=tailQ*2*V
low2=gain-G2-R-1e-14
print("(b) far left [-80,-40]: rigorous min lower bound = %.4e at y=%.3f"%(low2.min(),lo2[low2.argmin()]))
print("y<-80: bound at y=-80 for (G+remainder)e^{-lam y}: %.3e vs B(m-1)=%.4e"%((G2[0]+R[0])*math.exp(lam*80),B*(Mlow-1)))
print("sup H = V = %.6f   total %.0fs"%(V,time.time()-t0))
