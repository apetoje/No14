"""Tilted profile V_n = |G_n| e^{-theta* s} on the left of the line; shows the distant reservoir near s = -230 (Section 12)."""
import numpy as np, sys, math, time
from scipy.signal import lfilter
from psi_tables import *
n0=15; NMAX=int(sys.argv[1]); x=math.log2(3)
th=1/x; rho=math.log(3)*(1-(-th*math.log2(th)-(1-th)*math.log2(1-th)))
R=int(NMAX*x)+60; L=int(n0*x)-400; N0=2*3**(n0-1)
F=psi[n0][np.arange(L,R+1)%N0].astype(complex)*math.exp(rho*n0)   # rescaled: G_n = e^{rho n} psi_n
pw=2.0**-np.arange(1,54)
res=[]; t0=time.time(); prof={}
for n in range(n0+1,NMAX+1):
    M=3**n; W=R-L
    p=pow(2,L,M)
    B=(p<<(W+60))//M                     # binary expansion of frac(2^L/3^n), W+60 bits
    by=np.frombuffer(B.to_bytes((W+60+7)//8,'big'),dtype=np.uint8)
    bits=np.unpackbits(by)[-(W+60):].astype(np.float64)   # MSB first: bits[b] = b-th bit after point
    fr=np.zeros(W)
    for b in range(53):
        fr+=bits[b:b+W]*pw[b]
    ph=np.exp(2j*np.pi*fr)               # exponent L+i, i<W
    G=0.5*math.exp(rho)*ph*F[:-1]
    F=lfilter([1.0],[1.0,-0.5],G); L+=1
    a=np.abs(F); i=int(np.argmax(a))
    res.append((n,a[i],L+i))
    if n in (200,500,1000,2000): prof[n]=((L+np.arange(len(F)))-n*x, np.abs(F))
    if False:
        print(n,"M e^{rho n}=%.6e"%a[i],"nx-k*=%.3f"%(n*x-(L+i)),"%.0fs"%(time.time()-t0),flush=True)
import pickle; pickle.dump(prof,open('vprof.pkl','wb'))
