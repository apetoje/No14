"""Top eigenvalue of the tilted front operator in the box [-S,20] with a Dirichlet condition on the left
(Section 9, after Proposition 9.3): (1-lambda) S^2 and the effective barrier s_b = -4.1."""
import numpy as np, math, sys
x=math.log2(3); th=1/x
rho=math.log(3)*(1-(-th*math.log2(th)-(1-th)*math.log2(1-th)))
tst=math.log(x/(2*(x-1))); sig2=x*(x-1)
def lam(S,S2=20.0,h=1/128,iters=6000,A=50,phases=True):
    s=np.arange(-S,S2+h/2,h); Ns=len(s)
    # work with V = W e^{-theta* s}; T~V(s)=sum q(a) ph(s,a) V(s+x-a), q(a)=e^rho 2^-a e^{theta*(x-a)}
    q=[math.exp(rho)*0.5**a*math.exp(tst*(x-a)) for a in range(1,A+1)]
    idx=[]; 
    for a in range(1,A+1):
        sp=s+x-a; f=(sp+S)/h; i0=np.floor(f).astype(int); w=f-i0
        ok=(i0>=0)&(i0<Ns-1)         # outside grid: 0 (Dirichlet at far left, 0 far right)
        i0c=np.clip(i0,0,Ns-2)
        ph=np.exp(-2j*np.pi*np.exp2(s-a)) if phases else np.ones(Ns)
        idx.append((i0c,w,ok,q[a-1]*ph))
    V=np.exp(-((s+7)/10)**2).astype(complex)
    for it in range(iters):
        V2=np.zeros(Ns,complex)
        for i0,w,ok,c in idx:
            V2+=np.where(ok,c*((1-w)*V[i0]+w*V[i0+1]),0)
        nr=np.vdot(V,V2)/np.vdot(V,V)
        V=V2/np.abs(V2).max()
    return abs(nr)
print('sum q =',sum(math.exp(rho)*0.5**a*math.exp(tst*(x-a)) for a in range(1,200)))
for S in [20,30,45,60,90]:
    l=lam(S); d=1-l
    print('S=%3d  1-lambda=%.3e   (1-lam)*S^2=%.3f   Neumann pi^2 sig2/8=%.3f  Dirichlet pi^2 sig2/2=%.3f'%(S,d,d*S*S,math.pi**2*sig2/8,math.pi**2*sig2/2),flush=True)
