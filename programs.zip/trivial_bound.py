"""Remark 10.7: exponent of the trivial bound on the injections,
sup_{0<u<1} [ (sigma_c - sigma) u - (1-u) I(u x/(1-u)) ], with I the large deviation rate function of the step a - x
under the tilted geometric law q. Prints the supremum (equal to rho for sigma = 0), the maximizer u* = 1 - x/2,
and r(sigma) = rho - sup for sigma = 0, 0.1, 0.3, sigma_c."""
import math
from scipy.optimize import minimize_scalar
x = math.log2(3); be = (x-1)/x
H = lambda t: -t*math.log(t)-(1-t)*math.log(1-t)
rho = math.log(3)-x*H(1/x); tst = math.log(x/(2*(x-1))); sc = rho+tst*x
def I(v):
    f = lambda l: -(l*v-(math.log((1-be)*math.exp(l)/(1-be*math.exp(l)))-l*x))
    return -minimize_scalar(f, bounds=(0, -math.log(be)-1e-12), method='bounded').fun
print("rho = %.6f, sigma_c = %.5f, 1 - x/2 = %.4f" % (rho, sc, 1-x/2))
for sig in (0.0, 0.1, 0.3, sc):
    g = lambda u: -((sc-sig)*u-(1-u)*I(u*x/(1-u)))
    r = minimize_scalar(g, bounds=(1e-4, 0.99), method='bounded')
    print("sigma=%.3f  sup=%.5f  u*=%.4f  r(sigma)=%.5f" % (sig, -r.fun, r.x, rho+r.fun))
