"""psi_n(j)=B_n(j)+sum_t w_t(j) c_{n-t+1} on j=1..J (Theorem 6.2 with Xi=2^j).
D_i(A)=E[prod_{l<=i} e(-2^{j-A_l}3^{l-1}/3^n); A_i=A]; w_t(j)=sum_{A<=j} D_{t-1}(A) 2^{-(j-A)}, B(j)=sum_{A<=j} D_n(A).
Prints dist_2(B, span W)/||B||_2 and dist / e^{-rho n}."""
import sys, numpy as np, math
from scipy.signal import lfilter
x=math.log2(3); th=math.log(x/(2*(x-1))); rho=-(th*x-math.log(2*math.exp(th)-1))
def build(n,J):
    ph={}
    for r in range(1,n+1):
        M=3**r; v=1; a=np.empty(J+1,dtype=complex)
        for k in range(J+1): a[k]=np.exp(-2j*math.pi*v/M); v=(2*v)%M
        ph[r]=a
    W=np.zeros((J,n),dtype=complex); B=np.zeros(J,dtype=complex)
    for j in range(1,J+1):
        D=np.zeros(j+1,dtype=complex); D[0]=1.0   # A_0=0
        Ar=np.arange(j+1)
        for i in range(1,n+1):
            # column t=i uses D_{i-1}
            W[j-1,i-1]=np.sum(D*2.0**-(j-Ar))
            G=lfilter([0,0.5],[1,-0.5],D)          # G(A)=sum_{a>=1}2^-a D(A-a)
            D=G*ph[n-i+1][j-Ar]                     # phase e(-2^{j-A}/3^{n-i+1})
        B[j-1]=np.sum(D)
    return B,W
if __name__=="__main__":
    for n in [int(a) for a in sys.argv[1:]]:
        J=int(n*x)+25
        B,W=build(n,J)
        c,res,rk,sv=np.linalg.lstsq(W,-B,rcond=None)
        r=np.linalg.norm(B+W@c); 
        print("n=%3d J=%3d rank=%d  ||B||=%.3e  dist=%.3e  dist/||B||=%.3e  dist*e^{rho n}=%.3e  smin=%.2e"%(n,J,rk,np.linalg.norm(B),r,r/np.linalg.norm(B),r*math.exp(rho*n),sv[-1]),flush=True)
