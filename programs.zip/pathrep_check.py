"""Check of the path representation (Lemma 12.9):
V^B_n(s) = e^{rho n - theta* s} B_n(j) = E*_s[ e^{-theta* S_0} e(-sum_{k=0}^{n-1} 2^{S_k - x}) ; S_0 >= 0, S_k >= 1-kx (1<=k<=n-1) ],
S_n = s = j - nx, S_{k-1} = S_k + x - a_k, a_k i.i.d. q(a) = (1-beta) beta^{a-1}, beta = (x-1)/x.
Left side from the recursion B_n(j) = sum_{a=1}^{j} 2^{-a} e(-2^{j-a-nx}) B_{n-1}(j-a), B_n(0)=0 (n>=1), B_0 = 1."""
import math, cmath, itertools
x=math.log2(3); th=math.log(x/(2*(x-1))); rho=-(th*x-math.log(2*math.exp(th)-1)); beta=(x-1)/x
def e(y): return cmath.exp(-2j*math.pi*y)   # e(-y)
def Brec(n,J):
    B=[1.0+0j]*(J+1)
    for m in range(1,n+1):
        nb=[0j]*(J+1)
        for j in range(1,J+1):
            nb[j]=sum(2.0**-a*e(2.0**(j-a-m*x))*B[j-a] for a in range(1,j+1))
        B=nb
    return B
def Vpath(n,j):
    tot=0j
    for a in itertools.product(range(1,j+1),repeat=n):
        js=[j]                       # j_n, j_{n-1}, ..., j_0
        for k in range(n): js.append(js[-1]-a[k])
        jn_to_0=js[::-1]             # j_0..j_n
        if jn_to_0[0]<0 or any(jn_to_0[k]<1 for k in range(1,n)): continue
        S=[jn_to_0[k]-k*x for k in range(n+1)]
        w=1.0
        for ak in a: w*=(1-beta)*beta**(ak-1)
        tot+=w*math.exp(-th*S[0])*e(sum(2.0**(S[k]-x) for k in range(n)))
    return tot
for n in [1,2,3,4]:
    J=int(n*x)+3; B=Brec(n,J)
    for j in [1,int(n*x),int(n*x)+2]:
        lhs=math.exp(rho*n-th*(j-n*x))*B[j]; rhs=Vpath(n,j)
        print(n,j,"recursion %.12f%+.12fi   paths %.12f%+.12fi   |diff| %.1e"%(lhs.real,lhs.imag,rhs.real,rhs.imag,abs(lhs-rhs)))
