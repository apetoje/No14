"""Diffusive regime of the archimedean front (Conjecture 12.10(b), Remark 12.13), double precision:
compares n^{3/2} V^B_n at s = u sqrt(n) with c_sigma P^B |s| exp(-s^2/(2 sigma^2 n)), c_sigma = 0.8935.
Usage: python3 scaling_check.py N1 N2 ..."""
import sys, math
import numpy as np
from scipy.signal import lfilter
x=math.log2(3); th=math.log(x/(2*(x-1))); rho=-(th*x-math.log(2*math.exp(th)-1)); sig2=x*(x-1)
Ns=[int(v) for v in sys.argv[1:]]; N=max(Ns)
J=int(math.ceil(N*x))+int(12*N**0.5)+60; jj=np.arange(1,J+1); k=jj-1
B=np.ones(J+1,complex); er=math.exp(rho)
for n in range(1,N+1):
    nx=n*x; M=3**n; ph=np.empty(J,complex); lo=k<nx
    ph[lo]=np.exp(-2j*np.pi*np.exp2(k[lo]-nx))
    hi=np.nonzero(~lo)[0]
    if len(hi):
        r=pow(2,int(math.ceil(nx)),M); sh=max(0,M.bit_length()-60); Md=float(M>>sh); fr=np.empty(len(hi))
        for i in range(len(hi)): fr[i]=float(r>>sh)/Md; r=(r<<1)%M
        ph[hi]=np.exp(-2j*np.pi*fr)
    h=0.5*er*ph*B[:-1]; out=np.empty(J+1,complex); out[0]=0
    out[1:]=lfilter([1.0],[1.0,-0.5],h,zi=[0.0])[0]; B=out
    if n in Ns:
        s=np.arange(J+1)-nx; V=np.exp(-th*s)*B   # tilted
        print("n=%d"%n)
        for u in [-0.1,-0.25,-0.5,-1.0,-1.5,-2.0,-2.5]:
            i=int(np.argmin(np.abs(s-u*n**0.5))); c=n**1.5*V[i]/(abs(s[i])*math.exp(-s[i]**2/(2*sig2*n)))
            print("   u=%5.2f s=%8.2f  n^1.5 V/(|s|e^{-s^2/2s2n}) = %.5f%+.5fi"%(u,s[i],c.real,c.imag))
        for s0 in [-30,-15,-7]:
            i=int(np.argmin(np.abs(s-s0))); c=n**1.5*V[i]/abs(s[i])
            print("   s=%8.2f  n^1.5 V/|s| = %.5f%+.5fi"%(s[i],c.real,c.imag))
