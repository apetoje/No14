"""Coarse-grained certificate of Theorem 3.15: power iteration h -> min over lifts of K h at level m, normalized, and the
Collatz-Wielandt lower bound Lambda (Corollary 3.16, Remark 3.17: Lambda_m for m = 1..4 and h(2,1)).
Usage: python3 certificate_float.py m A iterations   (e.g. 2 60 400); saves cw_h_m{m}.npy"""
import numpy as np, sys, time
m=int(sys.argv[1]); A=int(sys.argv[2]); IT=int(sys.argv[3])
Mm=3**m; M1=3**(m+1)
units_m=np.array([u for u in range(Mm) if u%3]); nu=len(units_m)
uidx=-np.ones(Mm,np.int64); uidx[units_m]=np.arange(nu)
U1=np.array([u for u in range(M1) if u%3],dtype=np.int64)
AL,BE=np.meshgrid(U1,np.arange(M1,dtype=np.int64),indexing='ij'); AL=AL.ravel(); BE=BE.ravel()
proj=uidx[AL%Mm]*Mm+BE%Mm
S=nu*Mm
# aggregate weights: target depends on (a,b) only via a,b mod P (P=2*3^m period of 2 mod 3^(m+1)); use exact class weights truncated at A
P=2*3**m
from collections import defaultdict
# lower-bound class weights: sum_{a<=A, a=r mod P} 2^-a
cw=np.zeros(P+1)
for a in range(1,A+1): cw[(a-1)%P+1]+=2.0**-a
rs=[r for r in range(1,P+1) if cw[r]>1e-30]
rows=[];cols=[];vals=[]
t0=time.time()
for ra in rs:
  for rb in rs:
    w=cw[ra]*cw[rb]
    if w<1e-22: continue
    alp=(AL*pow(2,rb-ra,M1))%M1
    c=(2+pow(2,rb,M1)*(AL+BE-1)-2*alp)%M1
    ok=np.nonzero(c%3==0)[0]
    rows.append(ok); cols.append(uidx[alp[ok]%Mm]*Mm+(c[ok]//3)%Mm); vals.append(np.full(len(ok),3*w))
import scipy.sparse as sp
K=sp.csr_matrix((np.concatenate(vals),(np.concatenate(rows),np.concatenate(cols))),shape=(len(AL),S))
K.sum_duplicates()
print('built',time.time()-t0,'nnz',K.nnz,flush=True)
h=np.ones(S); lam=0
for it in range(IT):
    Kh=K@h
    new=np.full(S,np.inf); np.minimum.at(new,proj,Kh)
    lam=new.max(); h=new/lam
    if it%50==0: 
        r=K@h; q=np.where(h[proj]>1e-14, r/np.where(h[proj]>1e-14,h[proj],1), np.inf)
        print(it,'lam_est=%.6f'%lam,'CW lower=%.6f'%q.min(),'h(2,0) [state (2,1) of the paper]=%.4g'%h[uidx[2]*Mm],flush=True)
r=K@h; q=np.where(h[proj]>1e-14, r/np.where(h[proj]>1e-14,h[proj],1), np.inf)
print('FINAL m=%d CW lower bound lambda=%.6f  h(2,0) [state (2,1) of the paper]=%.4g  support=%.3f'%(m,q.min(),h[uidx[2]*Mm],np.mean(h>1e-14)))
np.save('cw_h_m%d.npy'%m,h)
