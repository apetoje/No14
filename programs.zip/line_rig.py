"""The line function psi_n(j) = phi_n(2^j), 0 <= j <= J, for 1 <= n <= N, with rigorous error bounds,
together with the archimedean front B_n(j) (Lemma 9.6).

On j >= 0 the system closes once the central values are known (Remark 9.7):
   psi_n(0) = phi_n(1),   psi_n(j) = ( e(-<2^{j-1}>_{3^n}/3^n) psi_{n-1}(j-1) + psi_n(j-1) ) / 2   (j >= 1),
   B_n(0)   = 0 (n >= 1), B_n(j) by the same recursion from B_{n-1};  psi_0 = B_0 = 1.
The central values phi_n(1) are computed on the negative half-line as in central_rig.py (with its error bounds).
Errors (units u = 2^-P, fixp.FP model): E_h = E (1+1e-6) + 77 |x_hat| + sqrt2, E_new(j) = (E_h(j-1)+E_new(j-1))/2 + sqrt2.

Output per n (one line): n, j*, s* = j*-nx, ln|psi_n(j*)| (j* = argmax), log2 of the error radius on the line,
  ln max|B_n|, e^{rho n} n^{3/2} max|psi_n|, e^{rho n} n^{3/2} max|B_n|,
  S_n = sum_{j>=1} (-s_j)_+ V_n(j) and S^B_n (tilted: V_n(j) = e^{rho n - theta* s_j} psi_n(j)).
Usage: python3 line_rig.py N P > out.txt"""
import sys, math, cmath
from fixp import FP, PHASE_ERR, SQ2, log2add
N = int(sys.argv[1]); P = int(sys.argv[2]); F = FP(P)
x = math.log2(3); th = math.log(x / (2 * (x - 1))); rho = -(th * x - math.log(2 * math.exp(th) - 1))
L = 8 * N + 400; J = int(math.ceil(N * x)) + int(12 * N ** 0.5) + 60
f = [(F.S, 0)] * L; E = [0.0] * L; T = [-math.inf] * L          # negative half-line (central values)
psi = [(F.S, 0)] * (J + 1); Ep = [0.0] * (J + 1)                  # psi_{n-1}(j), 0 <= j <= J
B = [(F.S, 0)] * (J + 1); Eb = [0.0] * (J + 1)
def lnarg(z):
    if z == (0, 0): return -math.inf, 0.0
    sh = max(0, max(abs(z[0]), abs(z[1])).bit_length() - 60)
    return math.log(math.hypot(z[0] >> sh, z[1] >> sh)) + (sh - P) * math.log(2), math.atan2(z[1] >> sh, z[0] >> sh)
for n in range(1, N + 1):
    M = 3 ** n
    # ---- central value phi_n(1)
    inv2 = pow(2, -1, M); r = 1; g = [None] * L
    for s in range(L):
        g[s] = F.cmul(F.phase_frac(r, M), f[s]); r = (r * inv2) % M
    new = [None] * L; En = [0.0] * L; Tn = [-math.inf] * L
    new[L - 1] = (0, 0); Tn[L - 1] = 0.0
    for t in range(L - 2, -1, -1):
        s = t + 1
        new[t] = ((g[s][0] + new[t + 1][0]) >> 1, (g[s][1] + new[t + 1][1]) >> 1)
        En[t] = 0.5 * (E[s] * (1 + 1e-6) + SQ2 + En[t + 1]) + SQ2
        ab = F.absf(f[s])
        tg = log2add(T[s] + 1e-9, math.log2(PHASE_ERR * ab) - P if ab > 0 else -math.inf)
        Tn[t] = log2add(tg, Tn[t + 1]) - 1.0
    f, E, T = new, En, Tn
    cen = f[0]; cen_err = E[0] + 2.0 ** (T[0] + P)     # in units u
    # ---- positive half-line
    r = 1
    npsi = [None] * (J + 1); nEp = [0.0] * (J + 1); nB = [None] * (J + 1); nEb = [0.0] * (J + 1)
    npsi[0] = cen; nEp[0] = cen_err; nB[0] = (0, 0); nEb[0] = 0.0
    for j in range(1, J + 1):
        ph = F.phase_frac(r, M); r = (r * 2) % M          # r = <2^{j-1}>
        h = F.cmul(ph, psi[j - 1]); hb = F.cmul(ph, B[j - 1])
        npsi[j] = ((h[0] + npsi[j - 1][0]) >> 1, (h[1] + npsi[j - 1][1]) >> 1)
        nB[j] = ((hb[0] + nB[j - 1][0]) >> 1, (hb[1] + nB[j - 1][1]) >> 1)
        nEp[j] = 0.5 * (Ep[j - 1] * (1 + 1e-6) + PHASE_ERR * min(1.0, F.absf(psi[j - 1])) + SQ2 + nEp[j - 1]) + SQ2
        nEb[j] = 0.5 * (Eb[j - 1] * (1 + 1e-6) + PHASE_ERR * min(1.0, F.absf(B[j - 1])) + SQ2 + nEb[j - 1]) + SQ2
    psi, Ep, B, Eb = npsi, nEp, nB, nEb
    # ---- diagnostics
    best = -math.inf; jb = 0; bestB = -math.inf; S = 0j; SB = 0j
    for j in range(0, J + 1):
        lv, av = lnarg(psi[j]); lb, ab_ = lnarg(B[j])
        if lv > best: best, jb = lv, j
        if lb > bestB: bestB = lb
        sj = j - n * x
        if j >= 1 and sj < 0:
            if lv > -math.inf: S += (-sj) * cmath.exp(complex(lv + rho * n - th * sj, av))
            if lb > -math.inf: SB += (-sj) * cmath.exp(complex(lb + rho * n - th * sj, ab_))
    errmax = math.log2(max(Ep)) - P
    norm = rho * n + 1.5 * math.log(n)
    print(n, jb, "%.4f" % (jb - n * x), "%.8f" % best, "%.1f" % errmax, "%.8f" % bestB,
          "%.6e" % math.exp(best + norm), "%.6e" % math.exp(bestB + norm),
          "%.8f %.8f" % (S.real, S.imag), "%.8f %.8f" % (SB.real, SB.imag), flush=True)
