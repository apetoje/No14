"""Independent cross-check of decimal exp/ln used in rig.py: exp by Taylor series with Lagrange remainder,
ln via exp and Newton (checked by exp(ln y)=y). Random arguments in the ranges used by the proofs."""
import random
from decimal import Decimal as D, getcontext
getcontext().prec=60
def exp_taylor(z):
    k=0; t=D(1); s=D(1); n=0
    # argument reduction z = r*2^k with |r|<1/2 (exact in decimal), then squaring
    while abs(z)>D('0.5'): z/=2; k+=1
    while True:
        n+=1; t=t*z/n; s+=t
        if abs(t)<D('1e-58'): break
    for _ in range(k): s=s*s
    return s
random.seed(1); worst=D(0)
for i in range(2000):
    z=D(repr(random.uniform(-60,30)))
    a=z.exp(); b=exp_taylor(z); worst=max(worst,abs(a-b)/b)
for i in range(500):
    y=D(repr(random.uniform(0.1,10))); l=y.ln(); worst=max(worst,abs(l.exp()-y)/y)
print("max relative discrepancy (decimal vs independent series): %.2e"%worst)
