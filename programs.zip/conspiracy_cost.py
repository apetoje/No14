"""Cost of a conspiracy: minimal weighted size max_m e^{sigma m}|c'_m| of controls c' that cancel the archimedean front
B_n on the line to relative accuracy eps (s=0 family), compared with the true central values."""
import numpy as np, math, sys
from span_distance import build
from psi_tables import psi
x=math.log2(3)
eps=1e-3
for n in (20,30,40,50,60):
    J=int(n*x)+20; B,W=build(n,J)            # columns t=1..n <-> level m=n-t+1
    m=n-np.arange(n)
    row=[]
    for sig in (0.3,0.45,0.5,0.536,0.549,0.6):
        Dinv=np.exp(-sig*m); A=W*Dinv[None,:]
        U,S,Vh=np.linalg.svd(A,full_matrices=False)
        b=U.conj().T@B; resid_out=np.linalg.norm(B-U@b)
        # truncated LS: keep k largest singular values until residual <= eps||B||
        best=None
        for k in range(1,len(S)+1):
            y=-(b[:k]/S[:k]); res=math.sqrt(max(np.linalg.norm(b[k:])**2+resid_out**2,0))
            if res<=eps*np.linalg.norm(B): best=np.abs(Vh[:k].conj().T@y).max(); break
        row.append("%s"%("%.1e"%best if best is not None else "  -  "))
    print("n=%d  max_m e^{sig m}|c'_m| for sig=0.30,0.45,0.50,0.536,0.549,0.60:"%n," ".join(row),flush=True)
print("true: max_m e^{0.549 m}|c_m| (m<=15) = %.3f"%max(math.exp(0.549*k)*abs(psi[k][0]) for k in range(1,16)))
