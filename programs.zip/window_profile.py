"""Normalized profile |G_n(nx+s)|/max on the cycle line for n = 1000,...,20000 (Table 5, first row)."""
import numpy as np, sys, math, time
from scipy.signal import lfilter
from psi_tables import *
n0=15; NMAX=int(sys.argv[1]); x=math.log2(3)
th=1/x; rho=math.log(3)*(1-(-th*math.log2(th)-(1-th)*math.log2(1-th)))
R=int(NMAX*x)+60; L=int(n0*x)-400; N0=2*3**(n0-1)
F=psi[n0][np.arange(L,R+1)%N0].astype(complex)*math.exp(rho*n0)   # rescaled: G_n = e^{rho n} psi_n
pw=2.0**-np.arange(1,54)
res=[]; t0=time.time(); SAVE={1000,1001,1002,1003,5000,5001,5002,10000,10001,10002,20000,20001}; prof={}
for n in range(n0+1,NMAX+1):
    M=3**n; W=R-L
    p=pow(2,L,M)
    B=(p<<(W+60))//M                     # binary expansion of frac(2^L/3^n), W+60 bits
    by=np.frombuffer(B.to_bytes((W+60+7)//8,'big'),dtype=np.uint8)
    bits=np.unpackbits(by)[-(W+60):].astype(np.float64)   # MSB first: bits[b] = b-th bit after point
    fr=np.zeros(W)
    for b in range(53):
        fr+=bits[b:b+W]*pw[b]
    ph=np.exp(2j*np.pi*fr)               # exponent L+i, i<W
    G=0.5*math.exp(rho)*ph*F[:-1]
    F=lfilter([1.0],[1.0,-0.5],G); L+=1
    a=np.abs(F); i=int(np.argmax(a))
    res.append((n,a[i],L+i))
    if n in SAVE: prof[n]=( (L+np.arange(len(F)))-n*x, F.copy())
    if n%1000==0 or n in (150,):
        print(n,"M e^{rho n}=%.6e"%a[i],"nx-k*=%.3f"%(n*x-(L+i)),"%.0fs"%(time.time()-t0),flush=True)
import pickle; pickle.dump({k:(v[0][(v[0]>-80)&(v[0]<15)],v[1][(v[0]>-80)&(v[0]<15)]) for k,v in prof.items()},open('prof.pkl','wb'))
