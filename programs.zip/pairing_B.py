"""Theorem 11.11 / Section 12: conserved pairing of the archimedean part: S_N = sum_j (-s_j)_+ e^{-theta* s_j} e^{rho N} B_N(j), s_j=j-Nx.
S_N -> P^B, since V~ = lim T~*^N V~_0.
Usage: python3 pairing_B.py 3200"""
import sys, numpy as np, math
N=int(sys.argv[1]); x=math.log2(3); AMAX=64
th=math.log(x/(2*(x-1))); rho=-(th*x-math.log(2*math.exp(th)-1))
J=int(N*x)+60; B=np.ones(J+1,dtype=complex)
for n in range(1,N+1):
    M=3**n; ph=np.empty(J+1,dtype=complex); v=1
    for k in range(J+1):
        ph[k]=np.exp(-2j*math.pi*(v/M)); v=(2*v)%M
    pb=ph*B; new=np.zeros(J+1,dtype=complex)
    for a in range(1,AMAX+1): new[a:]+=2.0**-a*pb[:J+1-a]
    new*=math.exp(rho); new[0]=0; B=new
    if n in (200,400,800,1600,3200) or n==N:
        s=np.arange(J+1)-n*x; w=np.where(s<0,-s,0)*np.exp(np.clip(-th*s,-700,700))
        S=np.sum(w*B); print("N=%5d  S_N=%.6f%+.6fi  |S_N|=%.6f"%(n,S.real,S.imag,abs(S)),flush=True)
