"""Fixed-point complex arithmetic with P fractional bits and a proved error budget.
Numbers are pairs of Python integers (re, im) representing (re + i im)/2^P.

Error model (u = 2^-P, |.| the complex modulus):
 * cmul(a,b): the exact product of the integer pairs is divided by 2^P with floor, so each component
   has error < 1 u, the modulus error is < sqrt(2) u = 1.4143 u.
 * half_sum(a,b) = floor((a+b)/2) componentwise: error < sqrt(2) u.
 * constants pi, and the table entries e(c 2^{-8(k+1)}), are computed with G = 64 guard bits and then
   rounded down; their errors are < 2 u per component (Taylor series run until the term vanishes at
   precision P+G; the accumulated floor errors and the neglected tail are < 2^{20} units of 2^{-(P+G)}).
 * phase(q) = e(-q/2^P), q an integer, is a product of at most NT+1 = 15 factors with errors
   < 2 sqrt(2) u each, so by induction its error is < 15*(2 sqrt(2)+sqrt(2)) u + 2 sqrt(2) u < 70 u.
 * angles: q = floor(r 2^P / M) differs from r 2^P / M by < 1, so e(-q/2^P) differs from e(-r/M) by
   < 2 pi u.  Hence  |phase_r - e(-r/M)| < PHASE_ERR u  with PHASE_ERR = 77.
"""
import math
G = 64
PHASE_ERR = 77.0
SQ2 = 1.4143

class FP:
    def __init__(self, P):
        self.P = P; self.S = 1 << P
        Q = P + G; SQ = 1 << Q
        def atan_inv(x):
            s = 0; t = SQ // x; k = 1; x2 = x * x; sg = 1
            while t:
                s += sg * (t // k); t //= x2; k += 2; sg = -sg
            return s
        self.PIQ = 4 * (4 * atan_inv(5) - atan_inv(239))      # pi * 2^Q (error < 2^12 units)
        self.Q = Q
        CH = 8; self.CH = CH; self.NT = 14
        self.TAB = [[self._cexp(c << (P - CH * (k + 1))) for c in range(256)] for k in range(self.NT)]
        self.LOWB = P - CH * self.NT

    def _cexp(self, th):
        """e(th) for th = integer / 2^P, computed at precision Q and rounded down to P bits."""
        P, Q = self.P, self.Q
        x = (2 * self.PIQ * th) >> P            # 2 pi th * 2^Q
        re = 0; im = 0; term = 1 << Q; k = 0
        while term:
            r = k % 4
            if r == 0: re += term
            elif r == 1: im += term
            elif r == 2: re -= term
            else: im -= term
            k += 1; term = (term * x >> Q) // k
        return (re >> G, im >> G)

    def cmul(self, a, b):
        P = self.P
        return ((a[0] * b[0] - a[1] * b[1]) >> P, (a[0] * b[1] + a[1] * b[0]) >> P)

    def phase_frac(self, r, M):
        """e(-r/M) with error < PHASE_ERR u."""
        P = self.P; q = (r << P) // M
        z = (self.S, 0)
        for k in range(self.NT):
            c = (q >> (P - self.CH * (k + 1))) & 255
            if c: z = self.cmul(z, self.TAB[k][c])
        lo = q & ((1 << self.LOWB) - 1)
        if lo: z = self.cmul(z, self._cexp(lo))
        return (z[0], -z[1])

    def absf(self, a):
        """upper bound for |a| as a float (units of 1)."""
        P = self.P
        sh = max(0, max(abs(a[0]), abs(a[1])).bit_length() - 50)
        return (math.hypot(a[0] >> sh, a[1] >> sh) + 2.0) * 2.0 ** (sh - P)

    def lnabs(self, a):
        P = self.P
        if a == (0, 0): return -math.inf
        sh = max(0, max(abs(a[0]), abs(a[1])).bit_length() - 60)
        return math.log(math.hypot(a[0] >> sh, a[1] >> sh)) + (sh - P) * math.log(2)

    def tofloat(self, a):
        """a as a Python complex (may underflow to 0 for tiny values)."""
        P = self.P
        sh = max(0, max(abs(a[0]), abs(a[1])).bit_length() - 60)
        return complex(math.ldexp(a[0] >> sh, sh - P), math.ldexp(a[1] >> sh, sh - P))


def log2add(a, b):
    """log2(2^a + 2^b)."""
    if a == -math.inf: return b
    if b == -math.inf: return a
    if a < b: a, b = b, a
    return a + math.log2(1.0 + 2.0 ** (b - a))
