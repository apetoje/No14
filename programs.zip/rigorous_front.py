"""Rigorous archimedean front V^B_n (tilted, Lemma 9.6) up to N+1 with a running bound E_n on the absolute error
(Theorem 11.11(b), Appendix A). Phases e(-f) by an own sine and cosine using only IEEE +,-,* (exact reduction
f -> g = f-k/4, |g| <= 1/8, Taylor polynomials of degree 17/16, error < 2e-15); fractional parts of 2^k/3^n from the
exact binary expansion of 2^L/3^n. Initial data V_0(j) = e^{-theta* j} as decimal enclosures (rig.py).
Error recursion E_n = P E_{n-1} + gam P|V_{n-1}| + beta*^64 + gam|V_n|, gam = 1e-12.
Writes front2_N{N}.npz, used by enclosure_PB.py. Usage: python3 rigorous_front.py 20000  (long run)"""
import numpy as np, math, sys, time
from decimal import Decimal as D
import rig
N=int(sys.argv[1]); A=64
X=rig.X; BE=(X-1)/X; TH=(X/(2*(X-1))).ln()
x=float(X); be=float(BE); th=float(TH)
q=np.array([float((1-BE)*BE**(a-1)) for a in range(1,A+1)])     # relative error < u
tail=float(BE**A)*1.01
u=2.0**-53; gam=1e-12
J=int((N+1)*x)+80; Lb=J+64; j=np.arange(J+1)
V=np.array([float((-TH*k).exp()) for k in range(J+1)]).astype(complex)
E=np.abs(V)*1e-15
TWO_PI=2*math.pi
cs=[(-1)**k/math.factorial(2*k) for k in range(9)]; ss=[(-1)**k/math.factorial(2*k+1) for k in range(9)]
def eminus(f):
    k=np.rint(4*f); g=f-k/4; t=TWO_PI*g; t2=t*t
    c=np.zeros_like(t); s=np.zeros_like(t)
    for a in reversed(cs): c=c*t2+a
    for a in reversed(ss): s=s*t2+a
    s=s*t
    kk=k.astype(np.int64)%4     # e(-f)=e(-g)e(-k/4)=(cos t - i sin t)*(-i)^k
    z=c-1j*s
    return np.where(kk==0,z,np.where(kk==1,-1j*z,np.where(kk==2,-z,1j*z)))
W=2.0**-(np.arange(1,61)); out={}; t0=time.time()
for n in range(1,N+2):
    M=3**n; Z=(1<<Lb)//M; nb=(Lb+8)//8*8
    bits=np.unpackbits(np.frombuffer(Z.to_bytes(nb//8,'big'),dtype=np.uint8))
    start=nb-Lb+np.arange(J+1)
    fr=np.lib.stride_tricks.sliding_window_view(bits,60)[start].astype(np.float64)@W   # exact sum of 60 bits? <=53 significant -> error <2^-53
    ph=eminus(fr)
    pv=ph*V; aV=np.sqrt(V.real*V.real+V.imag*V.imag)*(1+4*u)
    new=np.zeros(J+1,dtype=complex); newE=np.zeros(J+1)
    for a in range(1,A+1):
        new[a:]+=q[a-1]*pv[:J+1-a]
        newE[a:]+=q[a-1]*(E[:J+1-a]+gam*aV[:J+1-a])
    newE+=tail+gam*np.sqrt(new.real*new.real+new.imag*new.imag)
    new[0]=0; newE[0]=0; V,E=new,newE
    if n in (N,N+1): out[n]=(j-n*x,V.copy(),E.copy())
    if n%5000==0: print(n,"%.0fs"%(time.time()-t0),flush=True)
np.savez('front2_N%d.npz'%N,s0=out[N][0],V0=out[N][1],E0=out[N][2],s1=out[N+1][0],V1=out[N+1][1],E1=out[N+1][2])
s,V,E=out[N]; w=np.where(s<0,-s,0)
S=np.sum(w*V); errS=np.sum((w+1e-9)*(E+0))+np.sum(1e-9*np.abs(V))+1e-12
print("N=%d S_N=%.7f%+.7fi |S_N|=%.7f errS=%.2e L1=%.6f"%(N,S.real,S.imag,abs(S),errS,np.abs(V).sum()))
