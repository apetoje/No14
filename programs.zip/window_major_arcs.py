"""Window recursion around the cycle line (Proposition 6.5) for n <= NMAX, seeded with the exact table at level 15.
Prints M_n, the position k_n of the maximum and nx - k_n (Table 3, Theorem 13.1).
Usage: python3 window_major_arcs.py 150"""
import numpy as np, sys, math, time
# window recursion on the cycle line: psi_n(k)=1/2 psi_n(k-1)+1/2 e(2^{k-1}/3^n) psi_{n-1}(k-1)
from psi_tables import *   # exact tables psi[n], n<=15
n0=15; NMAX=int(sys.argv[1]); x=math.log2(3)
R=int(NMAX*x)+60; L=int(n0*x)-400
N0=2*3**(n0-1)
ks=np.arange(L,R+1)
F=psi[n0][ks%N0].astype(complex)    # values on window, index i <-> k=L+i
out=[]
t0=time.time()
for n in range(n0+1,NMAX+1):
    M=3**n
    Lnew=L+1
    # phases e(2^{k-1}/3^n) for k in [Lnew,R]  -> exponents k-1 in [L, R-1]
    p=pow(2,L,M); fr=np.empty(R-L)
    sh=1<<60
    for i in range(R-L):
        fr[i]=(p*sh//M)/sh
        p=(p*2)%M
    ph=np.exp(2j*np.pi*fr)              # ph[i] for exponent L+i
    G=0.5*ph*F[:-1]                     # g at k=L+1+i uses psi_{n-1}(L+i)
    # psi_n(k)= 1/2 psi_n(k-1)+G ; unknown psi_n(L) set 0
    from scipy.signal import lfilter
    Fn=lfilter([1.0],[1.0,-0.5],G)
    F=Fn; L=Lnew
    a=np.abs(F); i=int(np.argmax(a)); k=L+i
    out.append((n,a[i],k))
    if n in (16,17,18,20,30,40,50,60,80,100,120,150):
        print(n,"M=%.6e"%a[i],"k*=%d"%k,"nx-k*=%.3f"%(n*x-k),"log2n=%.3f"%math.log2(n),"time %.0fs"%(time.time()-t0),flush=True)
np.save('window_out.npy',np.array(out))
