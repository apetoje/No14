"""Construction of the supersolution H_2 of Proposition 11.10 (source G + G_1, H >= G + G_1 + K^T H, sup H = 30.9366),
same scheme as build_H4.py. Writes H5_params.json and H5_nodes.npy (included); verified by verify_H2.py.
Usage: python3 build_H5.py 18000 0.02 0.15 8"""
import numpy as np, math, scipy.sparse as sp, scipy.sparse.linalg as spl, json, sys
x=math.log2(3); be=(x-1)/x
YL=40.0; yc=5.0; nint=int(sys.argv[1]); mu0=float(sys.argv[2]); lam=float(sys.argv[3])
CK=int(sys.argv[4]) if len(sys.argv)>4 else 3; CMAX=400; C=np.arange(2,CMAX+1); Q2=(C-1)*(1-be)**2*be**(C-2)
m=np.sum(Q2*np.exp(lam*(C-2*x))); B=mu0/(m-1)
h=(yc+YL)/nint; y=-YL+h*np.arange(nint+1); NN=nint+1
def T(uu):
    a=np.arange(1,900); qa=(1-be)*be**(a-1); return np.sum(qa*np.maximum(a-x-uu,0))
def G(z): return 2*math.pi*2**(z-x)*(-z)+T(-z) if z<0 else ((1-be)*(x-1-z) if z<x-1 else 0.0)
Gy0=np.array([G(z) for z in y]); qa_=(1-be)*be**np.arange(0,80)
Gy=Gy0+np.array([sum(qa_[a-1]*G(z-x+a) for a in range(1,81)) for z in y]); mu=mu0*np.exp(lam*np.minimum(y,0))
def build():
    rows=[];cols=[];vals=[]; r0=Gy+mu; rV=np.zeros(NN); rH=np.zeros(NN)
    for c,q in zip(C,Q2):
        src=y+c-2*x; w=np.full(NN,q)
        if 3<=c<=CK:
            ss=np.minimum(src,c-1); a=np.arange(1,c)
            g=np.abs(np.exp(-2j*math.pi*2.0**(ss[:,None]-a[None,:])).mean(axis=1))
            w=q*np.where(src<c-1,g,1.0)
        left=src<-YL; right=src>yc; mid=~left&~right
        r0=r0+np.where(left,-w*B*np.exp(lam*np.minimum(src,0)),0); rH=rH+np.where(right,w,0); rV=rV+np.where(left,w,0)
        t=(src[mid]+YL)/h; i0=np.floor(t).astype(int); fr=t-i0; ii=np.nonzero(mid)[0]; i0=np.minimum(i0,nint-1); fr=t-i0; last=np.zeros(len(i0),bool)
        rows+=[ii,ii[~last]]; cols+=[i0,i0[~last]+1]; vals+=[w[mid]*(1-fr),(w[mid]*fr)[~last]]
        rH[ii[last]]+=(w[mid]*fr)[last]
    K=sp.csr_matrix((np.concatenate(vals),(np.concatenate(rows),np.concatenate(cols))),shape=(NN,NN))
    lu=spl.splu((sp.identity(NN)-K).tocsc()); return lu.solve(r0),lu.solve(rV),lu.solve(rH)
HG,HV,HH=build()
F=lambda t:-B*np.exp(lam*np.minimum(t,0))
sel=y<=-30
istar=np.nonzero(y>=yc-(2*x-2))[0][0]
for it in range(20):
    # unknowns V,Hs: H=HG+V*HV+Hs*HH ; eq1: Hs=H[istar]; eq2: LS of D=H-(V+F) on sel
    # eq2 normal equation in V for given Hs: sum (dG+V dV+Hs dH)*dV=0 with dV=HV-1
    dG=HG[sel]-F(y[sel]); dV=HV[sel]-1; dH=HH[sel]
    M=np.array([[np.dot(dV,dV),np.dot(dH,dV)],[HV[istar],HH[istar]-1]]); r=np.array([-np.dot(dG,dV),-HG[istar]])
    V,Hs=np.linalg.solve(M,r); H=HG+V*HV+Hs*HH
    inew=np.nonzero(y>=yc-(2*x-2))[0][np.argmax(H[y>=yc-(2*x-2)])]
    if inew==istar: break
    istar=inew
Hs=max(Hs,H[y>=yc-(2*x-2)].max())+1e-9
D=H-(V+F(y))
print("it=%d V=%.9f Hs=%.9f maxH=%.6f B=%.5f m=%.6f  max|D| on [-40,-30]=%.2e  D(-20)=%.2e D(-10)=%.2e"%(it,V,Hs,H.max(),B,m,np.abs(D[sel]).max(),D[np.searchsorted(y,-20)],D[np.searchsorted(y,-10)]))
json.dump(dict(YL=YL,yc=yc,nint=nint,h=h,lam=lam,B=B,V=V,Hs=Hs,mu0=mu0,m=m),open('H5_params.json','w')); np.save('H5_nodes.npy',H)
