"""Minimal rigorous enclosures with Python's decimal module (exp and ln are correctly rounded by the
General Decimal Arithmetic specification). Every returned value v carries an absolute error < RAD*max(1,|v|)."""
from decimal import Decimal as D, getcontext
getcontext().prec=50
RAD=D('1e-40')
def pi_():
    # Machin: pi = 16 atan(1/5) - 4 atan(1/239); alternating series, remainder < first omitted term
    def atan_inv(n):
        x=D(1)/n; x2=x*x; s=D(0); t=x; k=1; sign=1
        while t>D('1e-60'):
            s+=sign*t/k; t*=x2; k+=2; sign=-sign
        return s
    return 16*atan_inv(5)-4*atan_inv(239)
PI=pi_()
LN2=D(2).ln(); LN3=D(3).ln(); X=LN3/LN2
def exp2(z): return (D(z)*LN2).exp()
def cos2pi(f):
    """cos(2 pi f) for |f|<=1, Taylor series with remainder bound (terms decrease after k>|theta|)."""
    th=2*PI*D(f); th2=th*th; s=D(1); t=D(1); k=0
    while True:
        t=-t*th2/((2*k+1)*(2*k+2)); k+=1; s+=t
        if abs(t)<D('1e-48') and k>abs(th): break
    return s
def sin2pi(f):
    th=2*PI*D(f); th2=th*th; s=th; t=th; k=0
    while True:
        t=-t*th2/((2*k+2)*(2*k+3)); k+=1; s+=t
        if abs(t)<D('1e-48') and k>abs(th): break
    return s
def up(v):   # float >= v (v Decimal with error < RAD)
    f=float(v+RAD*max(1,abs(v))); return f*(1+2**-52) if f>0 else f*(1-2**-52)
def lo(v):
    f=float(v-RAD*max(1,abs(v))); return f*(1-2**-52) if f>0 else f*(1+2**-52)
