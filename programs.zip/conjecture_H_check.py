"""Check of Conjecture 5.2 (H_sigma) with sigma = (1/2) ln 3 in the Collatz case (Table 8).
For each level m the program prints 3^{m/2} max_{1<=r<=m+1} |phi_m(2^{-r})| and the root mean square,
using the exact tables for m <= 15 and the first-order recursion of Proposition 6.5 on the window
j in [L,8] for 16 <= m <= MMAX (moving L from -1500 to -2500 does not change any printed digit).
It also fits the decay rate for m >= 100. Usage: python3 conjecture_H_check.py 400 -3000"""
import numpy as np, sys, math
from scipy.signal import lfilter
from psi_tables import *
n0 = 15; MMAX = int(sys.argv[1]); L = int(sys.argv[2]); R = 8; N0 = 2*3**(n0-1)
F = psi[n0][np.arange(L, R+1) % N0].astype(complex)
show = {20, 40, 100, 150, 200, 300, 350, 400}; logs = []
for m in range(n0+1, MMAX+1):
    M = 3**m; W = R-L; p = pow(2, L, M); fr = np.empty(W); sh = 1 << 60
    for i in range(W):
        fr[i] = (p*sh//M)/sh; p = p*2 % M
    F = lfilter([1.0], [1.0, -0.5], 0.5*np.exp(2j*np.pi*fr)*F[:-1]); L += 1
    j = L+np.arange(len(F)); sel = (j <= -1) & (j >= -(m+1)); a = np.abs(F[sel])
    mx, rms = a.max(), math.sqrt(np.mean(a**2))
    if m >= 100: logs.append((m, math.log(mx), math.log(rms)))
    if m in show:
        print("m=%3d  3^{m/2} max = %.2f   3^{m/2} rms = %.3f" % (m, 3**(m/2)*mx, 3**(m/2)*rms), flush=True)
mm = np.array(logs)
print("fitted decay rate for m>=100: max %.3f, rms %.3f" % (-np.polyfit(mm[:, 0], mm[:, 1], 1)[0], -np.polyfit(mm[:, 0], mm[:, 2], 1)[0]))
