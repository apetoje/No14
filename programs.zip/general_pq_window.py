"""General (p,q) with uniform digits {1,...,p-1}: exact tables up to level n0 and window recursion up to NMAX (Table 7,
peak shift for (3,4), independence of the left edge J0). Usage: python3 general_pq_window.py p q n0 NMAX J0 [v]"""
import numpy as np, sys, math, time
from scipy.signal import lfilter
p=int(sys.argv[1]); q=int(sys.argv[2]); n0=int(sys.argv[3]); NMAX=int(sys.argv[4]); J0=int(sys.argv[5]); v=int(sys.argv[6]) if len(sys.argv)>6 else 1
x=math.log(q)/math.log(p)
h=lambda t:-t*math.log(t)-(1-t)*math.log(1-t)
rho=math.log(q)-math.log(p-1)-x*h(1/x)
tst=math.log(x/(p*(x-1)))
cs=np.arange(1,p)
def phase(fr): # E_c e(-c v fr)
    return np.mean(np.exp(-2j*np.pi*np.outer(fr,cs*v)),axis=1)
def order(p,M):
    o=1; y=p%M
    while y!=1: y=y*p%M; o+=1
    return o
# full tables on orbit v*p^j for n<=n0
F=None; Nprev=1
for n in range(1,n0+1):
    M=q**n; N=order(p,M)
    pw=np.empty(N,dtype=object); y=1
    fr=np.empty(N)
    for j in range(N): fr[j]=(y*(1<<60)//M)/2**60; y=y*p%M
    g=phase(fr)*(np.tile(F,N//Nprev) if n>1 else 1.0)*(p-1)/p
    xx=np.roll(g,1)
    yv=lfilter([1.0],[1.0,-1.0/p],xx); pl=yv[-1]/(1-(1.0/p)**N)
    K=min(N,2000); yv[:K]+=((1.0/p)**np.arange(1,K+1))*pl
    F=yv; Nprev=N
# window
R=int(NMAX*x)+60; L=int(n0*x)+J0
W=F[np.arange(L,R+1)%Nprev]*math.exp(rho*n0)
res=[]; t0=time.time()
for n in range(n0+1,NMAX+1):
    M=q**n; m=R-L
    y=pow(p,L,M) if L>=0 else pow(pow(p,-1,M),-L,M)
    fr=np.empty(m)
    for i in range(m): fr[i]=(y*(1<<60)//M)/2**60; y=y*p%M
    g=phase(fr)*W[:-1]*(p-1)/p*math.exp(rho)
    W=lfilter([1.0],[1.0,-1.0/p],g); L+=1
    a=np.abs(W); i=int(np.argmax(a)); res.append((n,a[i],L+i))
np.save('gen_%d_%d_%d_%d.npy'%(p,q,J0,v),np.array(res))
print('p,q=',p,q,'x=%.5f rho=%.6f theta*=%.5f'%(x,rho,tst),'time %.0fs'%(time.time()-t0))
