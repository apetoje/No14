"""Central values phi_m(1), m <= N, in fixed-point integer arithmetic with P bits.
f_m(t) = phi_m(2^{-t}), f_m(t) = sum_{a>=1} 2^{-a} e(-<2^{-t-a}>/3^m) f_{m-1}(t+a)  (Lemma 2.1, j = -t <= 0),
computed as new[t] = (g[t+1] + new[t+1])/2 with g = phase * f.  Entries beyond t = L-1 are unknown (|f| <= 1);
a running bound E_m(t) on the absolute error (truncation + rounding) is propagated by the same recursion.
Usage: python3 central_mp.py N P  -> prints m, |phi_m(1)|, error bound"""
import sys, math
N=int(sys.argv[1]); P=int(sys.argv[2]); S=1<<P
def atan_inv(x):  # arctan(1/x) * S
    s=0; t=S//x; k=1; x2=x*x; sg=1
    while t: s+=sg*(t//k); t//=x2; k+=2; sg=-sg
    return s
PI=4*(4*atan_inv(5)-atan_inv(239))
def cexp_small(th):  # e(th), th = integer/S in [0,1): Taylor of exp(2 pi i th)
    x=(2*PI*th)>>P   # angle*S
    re=0; im=0; term=S; k=0
    while term:
        if k%4==0: re+=term
        elif k%4==1: im+=term
        elif k%4==2: re-=term
        else: im-=term
        k+=1; term=(term*x>>P)//k
    return re,im
CH=8; NT=14   # top 112 bits via tables
TAB=[[cexp_small(c<<(P-CH*(k+1))) for c in range(256)] for k in range(NT)]
LOWB=P-CH*NT
def cmul(a,b): return ((a[0]*b[0]-a[1]*b[1])>>P, (a[0]*b[1]+a[1]*b[0])>>P)
def phase(q):   # e(-q/S), q integer in [0,S)
    z=(S,0)
    for k in range(NT):
        c=(q>>(P-CH*(k+1)))&255
        if c: z=cmul(z,TAB[k][c])
    lo=q&((1<<LOWB)-1)
    x=(2*PI*lo)>>P; x2=(x*x)>>P
    z=cmul(z,(S-x2//2, x - ((x2*x)>>P)//6))
    return (z[0],-z[1])
L=8*N+400
f=[(S,0)]*L; E=[0.0]*L   # E: error bounds in units of 2^ROUND_LOG2 plus truncation part T
TR=[0.0]*L
ROUND_LOG2=math.log2(200.0)-P   # rounding unit, kept as log2
for m in range(1,N+1):
    M=3**m; inv2=pow(2,-1,M); x=1; g=[None]*L
    for s in range(L):
        g[s]=cmul(phase((x<<P)//M),f[s]); x=(x*inv2)%M
    new=[None]*L; En=[0.0]*L; Tn=[0.0]*L
    new[L-1]=(0,0); Tn[L-1]=1.0
    for t in range(L-2,-1,-1):
        a=g[t+1]; b=new[t+1]
        new[t]=((a[0]+b[0])>>1,(a[1]+b[1])>>1)
        En[t]=0.5*(E[t+1]+1+En[t+1])+1          # rounding, in units 2^ROUND_LOG2
        Tn[t]=0.5*(TR[t+1]+Tn[t+1])              # truncation (absolute)
        if Tn[t]<1e-300: Tn[t]=0.0
    f=new; E=En; TR=Tn
    re,im=f[0]; v=math.hypot(re/S,im/S)

    errlog2=max(math.log2(E[0])+ROUND_LOG2, math.log2(TR[0]) if TR[0]>0 else -1e9)
    sh=max(0,max(abs(re),abs(im)).bit_length()-60)
    lnphi=math.log(math.hypot(re>>sh,im>>sh))+sh*math.log(2)-P*math.log(2)
    print(m, "%.10f"%lnphi, "%.6f"%math.atan2(im>>sh,re>>sh), "log2err<=%.1f"%(errlog2+1), "log2|phi|=%.1f"%(lnphi/math.log(2)), flush=True)
