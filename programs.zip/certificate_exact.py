"""Exact rational verification of the certificate (Corollary 3.16) for m = 1, 2: h is rounded to rationals with denominator
10^9 and Lambda is evaluated in exact arithmetic with the exact class weights 2^{-r}/(1-2^{-P}).
Usage: python3 certificate_float.py 2 60 400 ; python3 certificate_exact.py 2
(The program works in the coordinates (alpha,beta) with kappa = alpha+beta-1; the state (2,0) is the state (2,1) of the paper.)"""
from fractions import Fraction as Fr
import numpy as np, sys
m=int(sys.argv[1]); Mm=3**m; M1=3**(m+1); P=2*3**m
units=[u for u in range(Mm) if u%3]; uidx={u:i for i,u in enumerate(units)}
h=np.load('cw_h_m%d.npy'%m)
# rational h, rounded to 1e-9 grid (any positive h gives a valid certificate)
H=[Fr(int(round(v*10**9)),10**9) for v in h]
cw={r:Fr(1,2**r)/(1-Fr(1,2**P)) for r in range(1,P+1)}   # exact class weights
lam=None; s0=None
for al in range(M1):
    if al%3==0: continue
    for be in range(M1):
        tot=Fr(0)
        for ra in range(1,P+1):
            for rb in range(1,P+1):
                alp=(al*pow(2,rb-ra,M1))%M1
                c=(2+pow(2,rb,M1)*(al+be-1)-2*alp)%M1
                if c%3: continue
                tot+=3*cw[ra]*cw[rb]*H[uidx[alp%Mm]*Mm+(c//3)%Mm]
        hs=H[uidx[al%Mm]*Mm+be%Mm]
        r=tot/hs
        if lam is None or r<lam: lam=r
print('m=%d exact certified lambda >= %s = %.9f ; h(2,0) [state (2,1) of the paper]=%s'%(m,lam if m==1 else '...',float(lam),H[uidx[2]*Mm]))
