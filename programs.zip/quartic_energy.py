"""Proposition 12.4: quartic energy on the units F_n = sum |phi_n|^4, its ratios F_n/F_{n-1}, and M_n^4 <= F_n <= Q_n M_n^2,
for n <= 15 from the exact tables. Usage: python3 quartic_energy.py"""
import numpy as np
from psi_tables import psi
prev = None
for n in range(1, 16):
    a = np.abs(psi[n]); Q = np.sum(a**2); F = np.sum(a**4); M = a.max()
    print("n=%2d  Q_n=%.4f  F_n=%.4e  M_n^4/F_n=%.3f  F_n/(Q_n M_n^2)=%.3f%s" % (n, Q, F, M**4/F, F/(Q*M**2),
          "" if prev is None else "  F_n/F_{n-1}=%.4f" % (F/prev)))
    prev = F
