"""Two-step averaging for (2,3), (3,4), (4,5): best interval of length 1.3 times the largest upward jump and the maximal
kernel mass on it (Section 10, remark after Lemma 10.2: 0.32 and 0.17 for (3,4) and (4,5))."""
import numpy as np, math
def setup(p,q):
    x=math.log(q)/math.log(p); be=(x-1)/x; return x,be
def m_of_s(s,p,q,v,C=60):
    x,be=setup(p,q); cs=np.arange(1,p)
    psi=lambda t: np.mean(np.exp(-2j*np.pi*np.outer(np.atleast_1d(t),cs*v)),axis=1)
    tot=0.0
    for c in range(2,C):
        Q2=(c-1)*(1-be)**2*be**(c-2)
        a=np.arange(1,c)
        G=abs(np.mean(psi(float(p)**(s-a))))
        tot+=Q2*G*abs(psi(float(p)**(s+x-c))[0])
    return tot
for (p,q,vs) in [(2,3,[1]),(3,4,[1]),(4,5,[1,2])]:
    x,be=setup(p,q); L=2*(x-1)
    ss=np.arange(-3,4,0.002)
    for v in vs:
        mm=np.array([m_of_s(s,p,q,v) for s in ss])
        # find best interval of length 1.2*L with max m minimal
        w=int(round(1.3*L/0.002)); best=(9,0)
        for i in range(len(ss)-w):
            mx=mm[i:i+w].max()
            if mx<best[0]: best=(mx,ss[i])
        print('(%d,%d) v=%d  up-jump=%.3f  best interval [%.3f,%.3f] (len %.3f): max m=%.4f  delta=%.4f'%(p,q,v,L,best[1],best[1]+1.3*L,1.3*L,best[0],1-best[0]))
