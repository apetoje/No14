/* Full tables of phi_n on all units of Z/3^n by the first-order recursion of Proposition 6.5 (circle of
   discrete logarithms mod 2*3^(n-1)); prints M_n and the positions of the three largest values for n <= 18
   (Theorem 12.1, Table 3). Compile: gcc -O2 -o phi_tables phi_tables.c -lm ; run: ./phi_tables 18 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <complex.h>
#include <stdint.h>
int main(int argc,char**argv){
  int nmax=atoi(argv[1]);
  float complex *prev=NULL,*cur=NULL; long Np=0;
  for(int n=1;n<=nmax;n++){
    int64_t M=1; for(int i=0;i<n;i++) M*=3;
    long N=2*(M/3);
    cur=malloc(sizeof(float complex)*N);
    if(!cur){printf("oom\n");return 1;}
    /* g(k)=0.5*e(2^k/M)*prev(k mod Np); phi(k)=0.5 phi(k-1)+g(k-1) */
    /* first pass with phi(-1)=0 */
    double complex y=0; int64_t p=1; /* p=2^(k) mod M */
    /* we need g(k-1) at step k: compute running */
    double twopi=2*M_PI;
    double complex gprev; 
    /* g(N-1) for k=0 */
    int64_t pN1=1; { /* 2^(N-1) mod M */ int64_t b=2,e=N-1,r=1; while(e){ if(e&1) r=(__int128)r*b%M; b=(__int128)b*b%M; e>>=1;} pN1=r; }
    double complex f = (n==1)?1.0:(double complex)prev[(N-1)%Np];
    gprev=0.5*cexp(I*twopi*(double)pN1/(double)M)*f;
    for(long k=0;k<N;k++){
      y=0.5*y+gprev; cur[k]=(float complex)y;
      double complex fk=(n==1)?1.0:(double complex)prev[k%Np];
      gprev=0.5*cexp(I*twopi*(double)p/(double)M)*fk;
      p=(p*2)%M;
    }
    /* this used phi(-1)=0 at k=0 but wrap: phi(0)=0.5 phi(N-1)+g(N-1); correct by fixed point */
    double complex last=cur[N-1];
    double complex pl=last/(1-pow(0.5,(double)N)); /* true phi(N-1)*/
    double w=0.5; for(long k=0;k<N && w>1e-30;k++){ cur[k]+= (float complex)(w*pl); w*=0.5; }
    double best=0,b2=0,b3=0; long kb=0,k2=0,k3=0;
    for(long k=0;k<N;k++){ double a=cabsf(cur[k]); if(a>best){b3=b2;k3=k2;b2=best;k2=kb;best=a;kb=k;} else if(a>b2){b3=b2;k3=k2;b2=a;k2=k;} else if(a>b3){b3=a;k3=k;} }
    printf("%d %.10f k=%ld | %.6f k=%ld | %.6f k=%ld\n",n,best,kb,b2,k2,b3,k3); fflush(stdout);
    if(prev) free(prev); prev=cur; Np=N;
  }
  return 0;
}
