"""Fast window recursion with exact phases from the binary expansion of 2^L/3^n (Appendix A),
rescaled by e^{rho n}; prints G_n = e^{rho n} M_n and nx - k_n up to n = 50000 (Table 4, peak shift interval [6.266, 7.292]).
Usage: python3 window_large_n.py"""
import numpy as np, sys, math, time
from scipy.signal import lfilter
from psi_tables import *
n0=15; NMAX=int(sys.argv[1]); x=math.log2(3)
th=1/x; rho=math.log(3)*(1-(-th*math.log2(th)-(1-th)*math.log2(1-th)))
R=int(NMAX*x)+60; L=int(n0*x)-400; N0=2*3**(n0-1)
F=psi[n0][np.arange(L,R+1)%N0].astype(complex)*math.exp(rho*n0)   # rescaled: G_n = e^{rho n} psi_n
pw=2.0**-np.arange(1,54)
res=[]; t0=time.time()
for n in range(n0+1,NMAX+1):
    M=3**n; W=R-L
    p=pow(2,L,M)
    B=(p<<(W+60))//M                     # binary expansion of frac(2^L/3^n), W+60 bits
    by=np.frombuffer(B.to_bytes((W+60+7)//8,'big'),dtype=np.uint8)
    bits=np.unpackbits(by)[-(W+60):].astype(np.float64)   # MSB first: bits[b] = b-th bit after point
    fr=np.zeros(W)
    for b in range(53):
        fr+=bits[b:b+W]*pw[b]
    ph=np.exp(2j*np.pi*fr)               # exponent L+i, i<W
    G=0.5*math.exp(rho)*ph*F[:-1]
    F=lfilter([1.0],[1.0,-0.5],G); L+=1
    a=np.abs(F); i=int(np.argmax(a))
    res.append((n,a[i],L+i))
    if n%5000==0 or n in (150,):
        print(n,"M e^{rho n}=%.6e"%a[i],"nx-k*=%.3f"%(n*x-(L+i)),"%.0fs"%(time.time()-t0),flush=True)
np.save('window5_out.npy',np.array(res))
