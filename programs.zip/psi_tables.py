"""Exact tables psi[n][k] = phi_n(2^k) of the characteristic function of the Syracuse
random variable on all units of Z/3^n (n <= 15), k mod 2*3^(n-1), computed by the
first-order recursion of Proposition 6.5 (here with the conjugate convention e(+...),
which does not change absolute values). Imported by the window programs."""
import numpy as np
from scipy.signal import lfilter
from math import comb
def pow2_mod(N, M):
    out = np.empty(N, dtype=np.int64); out[0]=1; L=1
    while L<N:
        m=min(L,N-L); out[L:L+m]=(out[:m]*pow(2,L,M))%M; L+=m
    return out
nmax=15; psi={0:np.ones(1,complex)}; prev=None
for n in range(1,nmax+1):
    M=3**n; N=2*3**(n-1)
    g=np.exp(2j*np.pi*pow2_mod(N,M)/M)*(np.tile(prev,3) if n>1 else 1)*0.5
    y=lfilter([1.0],[1.0,-0.5],np.roll(g,1)); pl=y[-1]/(1-0.5**N)
    K=min(N,1200); y[:K]+=(0.5**np.arange(1,K+1))*pl
    psi[n]=y; prev=y
